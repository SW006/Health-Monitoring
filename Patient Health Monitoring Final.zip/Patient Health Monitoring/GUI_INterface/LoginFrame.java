package GUI_INterface;

import Notification_and_Reminder.Notifiable;
import User_Management.*;
import MDBS.DB_Connector;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Notification_and_Reminder.ReminderService;
import Emergency_Alert_System.PanicButton;
import Emergency_Alert_System.NotificationService;
import Notification_and_Reminder.EmailNotification;
import Notification_and_Reminder.SMSNotification;

public class LoginFrame extends JFrame {
    private JTextField emailField;
    private JPasswordField passwordField;
    private List<User> users;
    private JPanel mainPanel;
    private JLabel statusLabel;
    private ReminderService reminderService;
    private PanicButton panicButton;
    private NotificationService notificationService;
    private JFrame frame;
    private String email;
    private String password;

    public LoginFrame(List<User> users) {
        this.users = users;
        this.email = "your-email@example.com"; // These initializations might not be needed anymore
        this.password = "your-password";       //  since you're passing in the users list.
        initializeUI();
    }


    private void initializeUI() {
        setTitle("Patient Health Monitoring System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setResizable(false);

        mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                int w = getWidth();
                int h = getHeight();
                Color color1 = new Color(66, 139, 202);
                Color color2 = new Color(255, 255, 255);
                GradientPaint gp = new GradientPaint(0, 0, color1, w, h, color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, w, h);
            }
        };
        mainPanel.setLayout(new BorderLayout());

        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setOpaque(false);
        leftPanel.setPreferredSize(new Dimension(500, 0));
        leftPanel.setBorder(new EmptyBorder(40, 40, 40, 40));

        JPanel welcomePanel = new JPanel(new GridBagLayout());
        welcomePanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel welcomeLabel = new JLabel("Welcome Back!");
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 36));
        welcomeLabel.setForeground(new Color(51, 51, 51));
        welcomePanel.add(welcomeLabel, gbc);

        JLabel subtitleLabel = new JLabel("Sign in to continue to your account");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        subtitleLabel.setForeground(new Color(100, 100, 100));
        welcomePanel.add(subtitleLabel, gbc);

        leftPanel.add(welcomePanel, BorderLayout.CENTER);

        JPanel rightPanel = new JPanel(new GridBagLayout());
        rightPanel.setOpaque(false);
        rightPanel.setBorder(new EmptyBorder(40, 40, 40, 40));

        JPanel loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setOpaque(false);
        loginPanel.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(200, 200, 200), 1, true),
                new EmptyBorder(30, 30, 30, 30)
        ));

        gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel emailLabel = new JLabel("Email");
        emailLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        emailLabel.setForeground(new Color(51, 51, 51));
        loginPanel.add(emailLabel, gbc);

        emailField = new JTextField(20);
        emailField.setPreferredSize(new Dimension(300, 40));
        emailField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        emailField.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(200, 200, 200)),
                new EmptyBorder(5, 10, 5, 10)
        ));
        loginPanel.add(emailField, gbc);

        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        passwordLabel.setForeground(new Color(51, 51, 51));
        loginPanel.add(passwordLabel, gbc);

        passwordField = new JPasswordField(20);
        passwordField.setPreferredSize(new Dimension(300, 40));
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        passwordField.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(200, 200, 200)),
                new EmptyBorder(5, 10, 5, 10)
        ));
        loginPanel.add(passwordField, gbc);

        JButton loginButton = new JButton("Sign In");
        loginButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        loginButton.setForeground(Color.WHITE);
        loginButton.setBackground(new Color(66, 139, 202));
        loginButton.setPreferredSize(new Dimension(300, 45));
        loginButton.setFocusPainted(false);
        loginButton.setBorderPainted(false);
        loginButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        loginButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                loginButton.setBackground(new Color(51, 122, 183));
            }

            public void mouseExited(MouseEvent e) {
                loginButton.setBackground(new Color(66, 139, 202));
            }
        });

        loginButton.addActionListener(e -> handleLogin());
        loginPanel.add(loginButton, gbc);

        statusLabel = new JLabel("");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusLabel.setForeground(new Color(220, 53, 69));
        loginPanel.add(statusLabel, gbc);

        rightPanel.add(loginPanel);

        mainPanel.add(leftPanel, BorderLayout.WEST);
        mainPanel.add(rightPanel, BorderLayout.CENTER);

        add(mainPanel);

        getRootPane().setDefaultButton(loginButton);

        this.frame = this;

        EmailNotification emailNotification = new EmailNotification(this.email, this.password);
        SMSNotification smsNotification = new SMSNotification();
        notificationService = new NotificationService(emailNotification, smsNotification);
        reminderService = new ReminderService((Notifiable) notificationService);
        panicButton = null;
    }

    private void handleLogin() {
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());

        if (email.isEmpty() || password.isEmpty()) {
            statusLabel.setText("Please enter both email and password");
            return;
        }

        try {
            String query = "SELECT u.*, " +
                    "CASE " +
                    "  WHEN d.doctor_id IS NOT NULL THEN 'DOCTOR' " +
                    "  WHEN p.patient_id IS NOT NULL THEN 'PATIENT' " +
                    "  ELSE 'ADMIN' " +
                    "END as user_type, " +
                    "d.specialization, " +
                    "p.dob, p.gender, p.emergency_contact, p.primary_doctor_id " +
                    "FROM users u " +
                    "LEFT JOIN doctors d ON u.user_id = d.doctor_id " +
                    "LEFT JOIN patients p ON u.user_id = p.patient_id " +
                    "WHERE u.email = ? AND u.password = ?";

            Connection conn = DB_Connector.getConnection();
            if (conn == null) {
                statusLabel.setText("Database connection error. Please try again later.");
                return;
            }

            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, email);
            pstmt.setString(2, password);

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                User user = createUserFromResultSet(rs);
                if (user != null) {
                    statusLabel.setText("");
                    if (user instanceof Doctor) {
                        DoctorDashboard doctorDashboard = new DoctorDashboard((Doctor) user, (LoginFrame) frame);
                        // Set the doctor dashboard in the notification service
                        if (notificationService != null) {
                            notificationService.setDoctorDashboard(doctorDashboard);
                        }
                        doctorDashboard.setVisible(true);
                        this.setVisible(false);
                    } else if (user instanceof Patient) {
                        panicButton = new PanicButton((Patient) user, notificationService);
                        new PatientDashboard((Patient) user, (LoginFrame) frame, reminderService, panicButton);
                        this.setVisible(false);
                    } else if (user instanceof Administrator) {
                        new AdminDashboard((Administrator) user, (LoginFrame) frame);
                        this.setVisible(false);
                    }
                    return;
                }
            }
            statusLabel.setText("Invalid email or password");

            rs.close();
            pstmt.close();
        } catch (SQLException e) {
            statusLabel.setText("Database error occurred. Please try again later.");
            e.printStackTrace();
        }
    }

    private User createUserFromResultSet(ResultSet rs) throws SQLException {
        int userId = rs.getInt("user_id");
        String name = rs.getString("name");
        String email = rs.getString("email");
        String phone = rs.getString("phone");
        String password = rs.getString("password");
        String userType = rs.getString("user_type");

        switch (userType) {
            case "DOCTOR":
                String specialization = rs.getString("specialization");
                return new Doctor(userId, name, email, phone, password, specialization);

            case "PATIENT":
                String dob = rs.getString("dob");
                String genderStr = rs.getString("gender");
                char gender = (genderStr != null && !genderStr.isEmpty()) ? genderStr.charAt(0) : 'U';
                String emergencyContact = rs.getString("emergency_contact");
                int primaryDoctorId = rs.getInt("primary_doctor_id");

                Doctor primaryDoctor = null;
                if (primaryDoctorId > 0) {
                    String doctorQuery = "SELECT * FROM users u " +
                            "JOIN doctors d ON u.user_id = d.doctor_id " +
                            "WHERE d.doctor_id = " + primaryDoctorId;
                    ResultSet doctorRs = DB_Connector.executeQuery(doctorQuery);
                    if (doctorRs != null && doctorRs.next()) {
                        primaryDoctor = new Doctor(
                                doctorRs.getInt("user_id"),
                                doctorRs.getString("name"),
                                doctorRs.getString("email"),
                                doctorRs.getString("phone"),
                                doctorRs.getString("password"),
                                doctorRs.getString("specialization")
                        );
                    }
                }

                return new Patient(userId, name, email, phone, password, dob != null ? dob : "", gender, emergencyContact != null ? emergencyContact : "", primaryDoctor);

            case "ADMIN":
                return new Administrator(userId, name, email, phone, password);

            default:
                return null;
        }
    }

}