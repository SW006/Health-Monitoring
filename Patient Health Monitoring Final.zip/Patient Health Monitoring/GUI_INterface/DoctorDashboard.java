package GUI_INterface;

import Emergency_Alert_System.EmergencyAlert;
import User_Management.Doctor;
import User_Management.Patient;
import User_Management.User;
import Appointment_Scheduling.Appointment;
import Appointment_Scheduling.AppointmentManager;
import Doctor_Patient_Interaction.Prescription;
import Doctor_Patient_Interaction.Feedback;
import Doctor_Patient_Interaction.MedicalHistory;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class DoctorDashboard extends JFrame {
    private Doctor doctor;
    private LoginFrame loginFrame;
    private AppointmentManager appointmentManager;
    private JPanel mainPanel;
    private CardLayout cardLayout;
    private JLabel welcomeLabel;
    private JLabel statusLabel;
    private JTextArea patientDetailsArea;
    private JTextArea prescriptionArea;
    private JList<Patient> patientList;
    private DefaultListModel<Patient> patientListModel;
    private JPanel statsPanel;
    private JList<String> appointmentsList;
    private DefaultListModel<String> appointmentsListModel;
    private Patient selectedPatient;
    private Doctor currentDoctor;
    private JPanel patientPrescriptionsPanel;
    private JLabel patientCountLabel;
    private JPanel alertsPanel;
    private JTextArea alertsTextArea;

    public DoctorDashboard(Doctor doctor, LoginFrame loginFrame) {
        this.doctor = doctor;
        this.loginFrame = loginFrame;
        this.appointmentManager = AppointmentManager.getInstance();
        this.cardLayout = new CardLayout();
        this.currentDoctor = doctor;
        initializeUI();
    }

    public Doctor getDoctor() {
        return doctor;
    }

    private void initializeUI() {
        setTitle("Doctor Dashboard - Dr. " + doctor.getName());
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main panel with gradient background
        mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                int w = getWidth();
                int h = getHeight();
                Color color1 = new Color(66, 139, 202);
                Color color2 = new Color(255, 255, 255);
                GradientPaint gp = new GradientPaint(0, 0, color1, w, h, color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, w, h);
            }
        };
        mainPanel.setLayout(cardLayout);

        // Create and add panels
        mainPanel.add(createDashboardPanel(), "DASHBOARD");
        mainPanel.add(createPatientManagementPanel(), "PATIENT_MANAGEMENT");
        mainPanel.add(createAppointmentsPanel(), "APPOINTMENTS");

        // Create sidebar
        JPanel sidebar = createSidebar();

        // Create alerts panel
        alertsPanel = new JPanel(new BorderLayout());
        alertsPanel.setBorder(BorderFactory.createTitledBorder("Emergency Alerts"));
        alertsTextArea = new JTextArea();
        alertsTextArea.setEditable(false);
        JScrollPane alertsScrollPane = new JScrollPane(alertsTextArea);
        alertsPanel.add(alertsScrollPane, BorderLayout.CENTER);

        // Main layout
        setLayout(new BorderLayout());
        add(sidebar, BorderLayout.WEST);
        add(alertsPanel, BorderLayout.NORTH); // Add alerts panel to the top
        add(mainPanel, BorderLayout.CENTER);

        // Show dashboard by default
        cardLayout.show(mainPanel, "DASHBOARD");
        setVisible(true);
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(51, 51, 51));
        sidebar.setPreferredSize(new Dimension(200, 0));
        sidebar.setBorder(new EmptyBorder(20, 10, 20, 10));

        // Add user info at top
        JPanel userPanel = new JPanel();
        userPanel.setLayout(new BoxLayout(userPanel, BoxLayout.Y_AXIS));
        userPanel.setBackground(new Color(51, 51, 51));
        userPanel.setBorder(new EmptyBorder(0, 0, 20, 0));

        JLabel nameLabel = new JLabel("Dr. " + doctor.getName());
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        nameLabel.setForeground(Color.WHITE);
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel roleLabel = new JLabel("Doctor");
        roleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        roleLabel.setForeground(new Color(200, 200, 200));
        roleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        userPanel.add(nameLabel);
        userPanel.add(Box.createVerticalStrut(5));
        userPanel.add(roleLabel);
        sidebar.add(userPanel);
        sidebar.add(Box.createVerticalStrut(20));

        // Navigation buttons
        String[] navItems = {"Dashboard", "Patient Management", "Appointments"};
        for (String item : navItems) {
            JButton navButton = createNavButton(item);
            sidebar.add(navButton);
            sidebar.add(Box.createVerticalStrut(10));
        }

        // Logout button at bottom
        JButton logoutButton = createNavButton("Logout");
        logoutButton.setForeground(new Color(255, 100, 100));
        logoutButton.addActionListener(e -> handleLogout());
        sidebar.add(Box.createVerticalGlue());
        sidebar.add(logoutButton);

        return sidebar;
    }

    private JButton createNavButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(51, 51, 51));
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setMaximumSize(new Dimension(180, 40));
        button.setPreferredSize(new Dimension(180, 40));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addActionListener(e -> {
            cardLayout.show(mainPanel, text.toUpperCase().replace(" ", "_"));
        });

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(new Color(70, 70, 70));
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(new Color(51, 51, 51));
            }
        });

        return button;
    }

    private JPanel createDashboardPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        // Welcome section
        JPanel welcomePanel = new JPanel(new BorderLayout());
        welcomePanel.setBackground(Color.WHITE);
        welcomePanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(200, 200, 200)),
            new EmptyBorder(20, 20, 20, 20)
        ));

        welcomeLabel = new JLabel("Welcome back, Dr. " + doctor.getName());
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        welcomePanel.add(welcomeLabel, BorderLayout.WEST);

        // Stats grid
        statsPanel = new JPanel(new GridLayout(2, 2, 20, 20));
        statsPanel.setOpaque(false);

        updateDashboardStats();

        panel.add(welcomePanel, BorderLayout.NORTH);
        panel.add(statsPanel, BorderLayout.CENTER);
        return panel;
    }

    private void updateDashboardStats() {
        statsPanel.removeAll();

        List<Appointment> appointments = appointmentManager.getDoctorAppointments(doctor);
        long upcomingAppointments = appointments.stream()
            .filter(a -> a.getStatus().equals("SCHEDULED"))
            .count();
        long completedAppointments = appointments.stream()
            .filter(a -> a.getStatus().equals("COMPLETED"))
            .count();

        // Count unique patients with at least one appointment
        long uniquePatientCount = appointments.stream()
            .map(a -> a.getPatient().getUserId())
            .distinct()
            .count();

        statsPanel.add(createStatCard("Total Patients", String.valueOf(uniquePatientCount), "👥"));
        statsPanel.add(createStatCard("Upcoming Appointments", String.valueOf(upcomingAppointments), "📅"));
        statsPanel.add(createStatCard("Completed Appointments", String.valueOf(completedAppointments), "✅"));
        statsPanel.add(createStatCard("Specialization", doctor.getSpecialization(), "🎓"));

        statsPanel.revalidate();
        statsPanel.repaint();
    }

    private JPanel createStatCard(String title, String value, String icon) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(200, 200, 200)),
            new EmptyBorder(20, 20, 20, 20)
        ));

        JLabel iconLabel = new JLabel(icon);
        iconLabel.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        valueLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        titleLabel.setForeground(new Color(100, 100, 100));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        card.add(iconLabel);
        card.add(Box.createVerticalStrut(10));
        card.add(valueLabel);
        card.add(Box.createVerticalStrut(5));
        card.add(titleLabel);

        return card;
    }

    private JPanel createPatientManagementPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        // Create split pane
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(250);
        splitPane.setOpaque(false);

        // Left panel - Patient list
        JPanel leftPanel = new JPanel(new BorderLayout(10, 10));
        leftPanel.setBackground(Color.WHITE);
        leftPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(200, 200, 200)),
            new EmptyBorder(20, 20, 20, 20)
        ));

        // Search section
        JPanel searchPanel = new JPanel(new BorderLayout(10, 10));
        searchPanel.setBackground(Color.WHITE);
        JLabel searchLabel = new JLabel("Search Patients");
        searchLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        JTextField searchField = new JTextField();
        searchField.setPreferredSize(new Dimension(200, 30));
        searchField.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(200, 200, 200)),
            new EmptyBorder(5, 10, 5, 10)
        ));
        searchPanel.add(searchLabel, BorderLayout.NORTH);
        searchPanel.add(searchField, BorderLayout.CENTER);
        leftPanel.add(searchPanel, BorderLayout.NORTH);

        // Patient list
        patientListModel = new DefaultListModel<>();
        patientList = new JList<>(patientListModel);
        patientList.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        patientList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        patientList.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                    boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Patient) {
                    Patient patient = (Patient) value;
                    setText(patient.getName());
                    setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
                    if (isSelected) {
                        setBackground(new Color(66, 139, 202));
                        setForeground(Color.WHITE);
                    } else {
                        setBackground(Color.WHITE);
                        setForeground(Color.BLACK);
                    }
                }
                return this;
            }
        });
        JScrollPane listScrollPane = new JScrollPane(patientList);
        listScrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        leftPanel.add(listScrollPane, BorderLayout.CENTER);

        // Patient count
        patientCountLabel = new JLabel("Total Patients: " + doctor.getPatients().size());
        patientCountLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        patientCountLabel.setForeground(new Color(100, 100, 100));
        leftPanel.add(patientCountLabel, BorderLayout.SOUTH);

        // Right panel - Patient details and prescriptions
        JPanel rightPanel = new JPanel(new BorderLayout(10, 10));
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(200, 200, 200)),
            new EmptyBorder(20, 20, 20, 20)
        ));

        // Create tabbed pane for patient details and prescriptions
        JTabbedPane tabbedPane = new JTabbedPane();

        // Patient Details Tab
        JPanel detailsPanel = new JPanel(new BorderLayout(10, 10));
        detailsPanel.setBackground(Color.WHITE);
        JLabel detailsLabel = new JLabel("Patient Details");
        detailsLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        detailsPanel.add(detailsLabel, BorderLayout.NORTH);

        patientDetailsArea = new JTextArea();
        patientDetailsArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        patientDetailsArea.setEditable(false);
        patientDetailsArea.setLineWrap(true);
        patientDetailsArea.setWrapStyleWord(true);
        JScrollPane detailsScrollPane = new JScrollPane(patientDetailsArea);
        detailsScrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        detailsPanel.add(detailsScrollPane, BorderLayout.CENTER);
        tabbedPane.addTab("Patient Details", detailsPanel);

        // Prescriptions Tab
        patientPrescriptionsPanel = new JPanel(new BorderLayout(10, 10));
        patientPrescriptionsPanel.setBackground(Color.WHITE);

        // Prescriptions list
        DefaultListModel<String> prescriptionsListModel = new DefaultListModel<>();
        JList<String> prescriptionsList = new JList<>(prescriptionsListModel);
        prescriptionsList.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JScrollPane prescriptionsScrollPane = new JScrollPane(prescriptionsList);
        prescriptionsScrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        patientPrescriptionsPanel.add(prescriptionsScrollPane, BorderLayout.CENTER);

        // Add prescription button
        JButton addPrescriptionBtn = createModernButton("Add Prescription", new Color(66, 139, 202), "Add new prescription");
        addPrescriptionBtn.addActionListener(e -> {
            if (selectedPatient != null) {
                showAddPrescriptionDialog();
            } else {
                JOptionPane.showMessageDialog(this, "Please select a patient first.");
            }
        });
        patientPrescriptionsPanel.add(addPrescriptionBtn, BorderLayout.SOUTH);
        tabbedPane.addTab("Prescriptions", patientPrescriptionsPanel);

        // Medical History Tab
        JPanel medicalHistoryPanel = new JPanel(new BorderLayout(10, 10));
        medicalHistoryPanel.setBackground(Color.WHITE);

        JTextArea medicalHistoryArea = new JTextArea();
        medicalHistoryArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        medicalHistoryArea.setEditable(false);
        medicalHistoryArea.setLineWrap(true);
        medicalHistoryArea.setWrapStyleWord(true);
        JScrollPane medicalHistoryScrollPane = new JScrollPane(medicalHistoryArea);
        medicalHistoryScrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        medicalHistoryPanel.add(medicalHistoryScrollPane, BorderLayout.CENTER);
        tabbedPane.addTab("Medical History", medicalHistoryPanel);

        rightPanel.add(tabbedPane, BorderLayout.CENTER);

        // Add panels to split pane
        splitPane.setLeftComponent(leftPanel);
        splitPane.setRightComponent(rightPanel);

        // Add patient selection listener
        patientList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                selectedPatient = patientList.getSelectedValue();
                if (selectedPatient != null) {
                    // Update patient details
                    updatePatientDetails(selectedPatient);

                    // Update prescriptions list
                    updatePrescriptionsListForPatient(selectedPatient);

                    // Update medical history
                    updateMedicalHistory(medicalHistoryArea);
                }
            }
        });

        // Add search functionality
        searchField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void changedUpdate(javax.swing.event.DocumentEvent e) { filterPatients(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { filterPatients(); }
            public void insertUpdate(javax.swing.event.DocumentEvent e) { filterPatients(); }

            private void filterPatients() {
                String searchText = searchField.getText().toLowerCase();
                patientListModel.clear();
                for (Patient patient : doctor.getPatients()) {
                    if (patient.getName().toLowerCase().contains(searchText)) {
                        patientListModel.addElement(patient);
                    }
                }
            }
        });

        // Initial load of patients
        refreshPatientList();

        panel.add(splitPane, BorderLayout.CENTER);
        return panel;
    }

    private void updatePrescriptionsListForPatient(Patient patient) {
        if (patient == null || patientPrescriptionsPanel == null) return;

        DefaultListModel<String> listModel = new DefaultListModel<>();
        List<Prescription> prescriptions = appointmentManager.getPrescriptionList(patient);

        if (prescriptions.isEmpty()) {
            listModel.addElement("No prescriptions found");
        } else {
            for (Prescription prescription : prescriptions) {
                listModel.addElement(String.format("%s - %s (%s)",
                    prescription.getMedication(),
                    prescription.getDosage(),
                    prescription.getInstructions()));
            }
        }

        JList<String> prescriptionsList = new JList<>(listModel);
        prescriptionsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(prescriptionsList);
        scrollPane.setPreferredSize(new Dimension(300, 200));

        // Update the prescriptions panel using the direct reference
        patientPrescriptionsPanel.removeAll();
        patientPrescriptionsPanel.setLayout(new BorderLayout());

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.add(new JLabel("Prescriptions"), BorderLayout.WEST);

        JButton addButton = new JButton("Add Prescription");
        addButton.addActionListener(e -> showAddPrescriptionDialog());
        headerPanel.add(addButton, BorderLayout.EAST);

        patientPrescriptionsPanel.add(headerPanel, BorderLayout.NORTH);
        patientPrescriptionsPanel.add(scrollPane, BorderLayout.CENTER);

        patientPrescriptionsPanel.revalidate();
        patientPrescriptionsPanel.repaint();
    }

    private void updateMedicalHistory(JTextArea medicalHistoryArea) {
        if (selectedPatient != null) {
            MedicalHistory history = selectedPatient.getMedicalHistory();
            if (history != null) {
                medicalHistoryArea.setText(history.displayMedicalHistory());
            } else {
                medicalHistoryArea.setText("No medical history available for this patient.");
            }
        }
    }

    private void showAddPrescriptionDialog() {
        if (selectedPatient == null) {
            JOptionPane.showMessageDialog(this, "Please select a patient first");
            return;
        }

        JDialog dialog = new JDialog(this, "Add Prescription", true);
        dialog.setLayout(new BorderLayout());
        dialog.setSize(400, 300);
        dialog.setLocationRelativeTo(this);

        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JTextField medicationField = new JTextField();
        JTextField dosageField = new JTextField();
        JTextArea instructionsArea = new JTextArea(3, 20);
        JScrollPane instructionsScroll = new JScrollPane(instructionsArea);

        inputPanel.add(new JLabel("Medication:"));
        inputPanel.add(medicationField);
        inputPanel.add(new JLabel("Dosage:"));
        inputPanel.add(dosageField);
        inputPanel.add(new JLabel("Instructions:"));
        inputPanel.add(instructionsScroll);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");

        saveButton.addActionListener(e -> {
            String medication = medicationField.getText().trim();
            String dosage = dosageField.getText().trim();
            String instructions = instructionsArea.getText().trim();

            if (medication.isEmpty() || dosage.isEmpty() || instructions.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "All fields are required");
                return;
            }

            try {
                appointmentManager.addPrescription(selectedPatient, currentDoctor, medication, dosage, instructions);
                JOptionPane.showMessageDialog(dialog, "Prescription added successfully");
                dialog.dispose();
                updatePrescriptionsListForPatient(selectedPatient);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Error adding prescription: " + ex.getMessage());
            }
        });

        cancelButton.addActionListener(e -> dialog.dispose());

        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        dialog.add(inputPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void refreshPatientList() {
        patientListModel.clear();
        for (Patient patient : doctor.getPatients()) {
            patientListModel.addElement(patient);
        }
        if (patientCountLabel != null) {
            patientCountLabel.setText("Total Patients: " + doctor.getPatients().size());
        }
    }

    private void updatePatientDetails(Patient patient) {
        patientDetailsArea.setText(patient.getFullDetails());
    }

    private JPanel createAppointmentsPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel appointmentsPanel = new JPanel(new BorderLayout(10, 10));
        appointmentsPanel.setBackground(Color.WHITE);
        appointmentsPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(200, 200, 200)),
            new EmptyBorder(20, 20, 20, 20)
        ));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        JLabel headerLabel = new JLabel("My Appointments");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        JLabel descLabel = new JLabel("View and manage your appointments");
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descLabel.setForeground(new Color(100, 100, 100));
        headerPanel.add(headerLabel, BorderLayout.NORTH);
        headerPanel.add(descLabel, BorderLayout.CENTER);
        appointmentsPanel.add(headerPanel, BorderLayout.NORTH);

        // Appointments list
        JPanel listPanel = new JPanel(new BorderLayout(10, 10));
        listPanel.setBackground(Color.WHITE);
        appointmentsListModel = new DefaultListModel<>();
        appointmentsList = new JList<>(appointmentsListModel);
        appointmentsList.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(appointmentsList);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        listPanel.add(scrollPane, BorderLayout.CENTER);
        appointmentsPanel.add(listPanel, BorderLayout.CENTER);

        // Action buttons
        JPanel actionButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        actionButtons.setBackground(Color.WHITE);

        JButton refreshBtn = createModernButton("Refresh", new Color(100, 100, 100), "Update appointments list");
        JButton completeBtn = createModernButton("Mark Complete", new Color(66, 139, 202), "Mark selected appointment as complete");
        JButton cancelBtn = createModernButton("Cancel", new Color(244, 67, 54), "Cancel selected appointment");

        refreshBtn.addActionListener(e -> updateAppointmentsList());
        completeBtn.addActionListener(e -> {
            int index = appointmentsList.getSelectedIndex();
            if (index != -1) {
                List<Appointment> appointments = appointmentManager.getDoctorAppointments(doctor);
                if (index < appointments.size()) {
                    Appointment appointment = appointments.get(index);
                    if (!appointment.getStatus().equals("COMPLETED")) {
                        // Complete the appointment
                        appointmentManager.completeAppointment(appointment);

                        // Ensure the patient is assigned to the doctor
                        Patient patient = appointment.getPatient();
                        appointmentManager.assignPatientToDoctor(patient, doctor);

                        // Update the appointment status in the list
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                        String updatedText = String.format("%s - %s - COMPLETED",
                            dateFormat.format(appointment.getDate()),
                            patient.getName());
                        appointmentsListModel.set(index, updatedText);

                        // Refresh the patient list to show the newly associated patient
                        refreshPatientList();

                        // Select the patient in the list if they're not already selected
                        for (int i = 0; i < patientListModel.getSize(); i++) {
                            if (patientListModel.getElementAt(i).equals(patient)) {
                                patientList.setSelectedIndex(i);
                                break;
                            }
                        }

                        // Update the patient details
                        updatePatientDetails(patient);

                        // Update dashboard stats
                        updateDashboardStats();

                        JOptionPane.showMessageDialog(this,
                            "Appointment marked as completed and patient has been added to your list.",
                            "Success",
                            JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(this,
                            "This appointment is already completed.",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this,
                    "Please select an appointment to complete.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });

        cancelBtn.addActionListener(e -> {
            int index = appointmentsList.getSelectedIndex();
            if (index != -1) {
                List<Appointment> appointments = appointmentManager.getDoctorAppointments(doctor);
                if (index < appointments.size()) {
                    Appointment appointment = appointments.get(index);
                    if (!appointment.getStatus().equals("COMPLETED")) {
                        int confirm = JOptionPane.showConfirmDialog(this,
                            "Are you sure you want to cancel this appointment?",
                            "Confirm Cancellation",
                            JOptionPane.YES_NO_OPTION);
                        if (confirm == JOptionPane.YES_OPTION) {
                            appointmentManager.cancelAppointment(appointment);
                            updateAppointmentsList();
                        }
                    } else {
                        JOptionPane.showMessageDialog(this,
                            "Cannot cancel a completed appointment.",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this,
                    "Please select an appointment to cancel.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });

        actionButtons.add(refreshBtn);
        actionButtons.add(completeBtn);
        actionButtons.add(cancelBtn);
        appointmentsPanel.add(actionButtons, BorderLayout.SOUTH);

        // Initial load of appointments
        updateAppointmentsList();

        panel.add(appointmentsPanel, BorderLayout.CENTER);
        return panel;
    }

    private void updateAppointmentsList() {
        appointmentsListModel.clear();
        List<Appointment> appointments = appointmentManager.getDoctorAppointments(doctor);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        for (Appointment appointment : appointments) {
            appointmentsListModel.addElement(String.format("%s - %s - %s",
                dateFormat.format(appointment.getDate()),
                appointment.getPatient().getName(),
                appointment.getStatus()));
        }
        updateDashboardStats(); // Ensure dashboard stats are refreshed
    }

    private JButton createModernButton(String text, Color color, String tooltip) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(color);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(180, 40));
        button.setToolTipText(tooltip);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(color.darker());
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(color);
            }
        });

        return button;
    }


    private void handleLogout() {
        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to logout?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION
        );

        if (confirm == JOptionPane.YES_OPTION) {
            this.dispose();
            loginFrame.setVisible(true);
        }
    }
    public void receiveAlert(EmergencyAlert alert) {
        String alertMessage = String.format(
                "EMERGENCY from Patient: %s (%s)\n" +
                        "Type: %s\n" +
                        "Time: %tc\n" +
                        "Vitals: %s\n\n",
                alert.getPatient().getName(),
                alert.getPatient().getUserId(),
                alert.getAlertType(),
                alert.getTimestamp(),
                alert.getVitalSign().toString()
        );
        alertsTextArea.append(alertMessage);
    }
}