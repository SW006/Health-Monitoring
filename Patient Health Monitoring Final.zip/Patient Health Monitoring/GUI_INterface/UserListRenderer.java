package GUI_INterface;

import User_Management.User;

import javax.swing.*;
import java.awt.*;

class UserListRenderer extends DefaultListCellRenderer {
    @Override
    public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        if (value instanceof User) {
            User user = (User) value;
            setText(user.getName() + " (" + user.getEmail() + ")"); // Customize how the user is displayed
        }
        return this;
    }
}
