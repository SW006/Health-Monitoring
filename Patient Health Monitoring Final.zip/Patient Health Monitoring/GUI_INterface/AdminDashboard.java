package GUI_INterface;

import MDBS.DB_Connector;
import User_Management.*;
import Appointment_Scheduling.Appointment;
import Appointment_Scheduling.AppointmentManager;
import Doctor_Patient_Interaction.Prescription;
import Doctor_Patient_Interaction.Feedback;
import Doctor_Patient_Interaction.MedicalHistory;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.sql.ResultSet;
import java.sql.PreparedStatement; // Add this
import java.sql.Statement;       // Add this
import java.sql.SQLException;     // Add this
 // Add this

public class AdminDashboard extends JFrame {
    private Administrator admin;
    private LoginFrame loginFrame;
    private AppointmentManager appointmentManager;
    private JPanel mainPanel;
    private CardLayout cardLayout;
    private JLabel welcomeLabel;
    private JLabel statusLabel;
    private JTextArea userDetailsArea;
    private JList<User> userList;
    private DefaultListModel<User> userListModel;
    private JTextArea systemLogsTextArea;

    public AdminDashboard(Administrator admin, LoginFrame loginFrame) {
        this.admin = admin;
        this.loginFrame = loginFrame;
        this.appointmentManager = AppointmentManager.getInstance();
        this.cardLayout = new CardLayout();
        initializeUI();
    }

    private void initializeUI() {
        setTitle("Admin Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(800, 600));

        mainPanel = new JPanel();
        mainPanel.setLayout(cardLayout);

        // Welcome Panel
        JPanel welcomePanel = new JPanel(new BorderLayout());
        welcomePanel.setBackground(new Color(245, 245, 245)); // Lighter background
        welcomePanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        welcomeLabel = new JLabel("Welcome, " + admin.getName() + "!", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 26)); // Use Segoe UI
        welcomeLabel.setForeground(new Color(50, 50, 50));
        welcomePanel.add(welcomeLabel, BorderLayout.CENTER);

        // User Management Panel
        JPanel userPanel = createUserManagementPanel(); // Use the method you provided

        // Appointment Management Panel
        JPanel appointmentPanel = new JPanel(new BorderLayout());
        appointmentPanel.setBackground(new Color(245, 245, 245)); // Lighter background
        appointmentPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel appointmentHeaderLabel = new JLabel("Appointments", SwingConstants.CENTER);
        appointmentHeaderLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        appointmentHeaderLabel.setForeground(new Color(50, 50, 50));
        appointmentPanel.add(appointmentHeaderLabel, BorderLayout.NORTH);

        // Placeholder for appointment list - replace with actual component
        JTextArea appointmentListArea = new JTextArea("Appointment list will be displayed here.\n(Placeholder)");
        appointmentListArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        appointmentListArea.setEditable(false);
        JScrollPane appointmentListScrollPane = new JScrollPane(appointmentListArea);
        appointmentListScrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        appointmentPanel.add(appointmentListScrollPane, BorderLayout.CENTER);

        JPanel appointmentButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        appointmentButtonPanel.setBackground(new Color(245, 245, 245));
        JButton addAppointmentButton = createModernButton("Add Appointment", new Color(56, 142, 60), "Add a new appointment"); // Green
        addAppointmentButton.addActionListener(e -> {
            // Implement add appointment dialog/logic
            JOptionPane.showMessageDialog(this, "Add Appointment functionality not implemented yet.");
        });
        appointmentButtonPanel.add(addAppointmentButton);
        appointmentPanel.add(appointmentButtonPanel, BorderLayout.SOUTH);

        // Add panels to main panel
        mainPanel.add(welcomePanel, "welcome");
        mainPanel.add(userPanel, "users");
        mainPanel.add(appointmentPanel, "appointments");

        // Top Navigation Bar
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        topPanel.setBackground(new Color(230, 230, 230)); // Slightly darker top bar
        JButton welcomeButton = createModernButton("Home", new Color(52, 152, 219), "Go to the welcome screen");
        JButton usersButton = createModernButton("Users", new Color(52, 152, 219), "Manage users");
        JButton appointmentsButton = createModernButton("Appointments", new Color(52, 152, 219), "Manage appointments");
        JButton logoutButton = createModernButton("Logout", new Color(231, 76, 60), "Logout");

        welcomeButton.addActionListener(e -> cardLayout.show(mainPanel, "welcome"));
        usersButton.addActionListener(e -> cardLayout.show(mainPanel, "users"));
        appointmentsButton.addActionListener(e -> cardLayout.show(mainPanel, "appointments"));
        logoutButton.addActionListener(e -> {
            loginFrame.setVisible(true);
            dispose();
        });

        topPanel.add(welcomeButton);
        topPanel.add(usersButton);
        topPanel.add(appointmentsButton);
        topPanel.add(logoutButton);

        // Bottom Panel (for status label, refresh button, and logs)
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(new Color(230, 230, 230));

        statusLabel = new JLabel("Ready");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusLabel.setForeground(new Color(100, 100, 100));
        bottomPanel.add(statusLabel, BorderLayout.WEST);

        // Refresh Button
        JButton refreshButton = createModernButton("Refresh", new Color(70, 130, 180), "Refresh data");
        refreshButton.addActionListener(e -> {
            loadUsersFromDatabase(); //  Reload user data
            //  Add code to refresh any other data displayed in the dashboard
            updateSystemLogs("Data refreshed at " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
            statusLabel.setText("Data refreshed.");
        });
        bottomPanel.add(refreshButton, BorderLayout.EAST);

        // System Logs Text Area
        systemLogsTextArea = new JTextArea();
        systemLogsTextArea.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        systemLogsTextArea.setEditable(false);
        systemLogsTextArea.setLineWrap(true);
        systemLogsTextArea.setWrapStyleWord(true);
        JScrollPane logsScrollPane = new JScrollPane(systemLogsTextArea);
        logsScrollPane.setPreferredSize(new Dimension(300, 100)); // Adjust size as needed
        logsScrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        bottomPanel.add(logsScrollPane, BorderLayout.CENTER);

        add(topPanel, BorderLayout.NORTH);
        add(mainPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH); // Add the bottom panel

        cardLayout.show(mainPanel, "welcome");
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void updateSystemLogs(String logMessage) {
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        systemLogsTextArea.append(timeStamp + ": " + logMessage + "\n");
        // Keep only the last 100 lines (optional)
        String[] lines = systemLogsTextArea.getText().split("\n");
        if (lines.length > 100) {
            StringBuilder sb = new StringBuilder();
            for (int i = lines.length - 100; i < lines.length; i++) {
                sb.append(lines[i]).append("\n");
            }
            systemLogsTextArea.setText(sb.toString());
        }
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(51, 51, 51));
        sidebar.setPreferredSize(new Dimension(200, 0));
        sidebar.setBorder(new EmptyBorder(20, 10, 20, 10));

        // Add user info at top
        JPanel userPanel = new JPanel();
        userPanel.setLayout(new BoxLayout(userPanel, BoxLayout.Y_AXIS));
        userPanel.setBackground(new Color(51, 51, 51));
        userPanel.setBorder(new EmptyBorder(0, 0, 20, 0));

        JLabel nameLabel = new JLabel(admin.getName());
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        nameLabel.setForeground(Color.WHITE);
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel roleLabel = new JLabel("Administrator");
        roleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        roleLabel.setForeground(new Color(200, 200, 200));
        roleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        userPanel.add(nameLabel);
        userPanel.add(Box.createVerticalStrut(5));
        userPanel.add(roleLabel);
        sidebar.add(userPanel);
        sidebar.add(Box.createVerticalStrut(20));

        // Navigation buttons
        String[] navItems = {"Dashboard", "User Management", "System Logs"};
        for (String item : navItems) {
            JButton navButton = createNavButton(item);
            sidebar.add(navButton);
            sidebar.add(Box.createVerticalStrut(10));
        }

        // Logout button at bottom
        JButton logoutButton = createNavButton("Logout");
        logoutButton.setForeground(new Color(255, 100, 100));
        logoutButton.addActionListener(e -> handleLogout());
        sidebar.add(Box.createVerticalGlue());
        sidebar.add(logoutButton);

        return sidebar;
    }

    private JButton createNavButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(51, 51, 51));
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setMaximumSize(new Dimension(180, 40));
        button.setPreferredSize(new Dimension(180, 40));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addActionListener(e -> {
            cardLayout.show(mainPanel, text.toUpperCase().replace(" ", "_"));
        });

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(new Color(70, 70, 70));
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(new Color(51, 51, 51));
            }
        });

        return button;
    }

    private JPanel createDashboardPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        // Welcome section
        JPanel welcomePanel = new JPanel(new BorderLayout());
        welcomePanel.setBackground(Color.WHITE);
        welcomePanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(200, 200, 200)),
            new EmptyBorder(20, 20, 20, 20)
        ));

        welcomeLabel = new JLabel("Welcome back, " + admin.getName());
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        welcomePanel.add(welcomeLabel, BorderLayout.WEST);

        // Stats grid
        JPanel statsPanel = new JPanel(new GridLayout(2, 2, 20, 20));
        statsPanel.setOpaque(false);

        List<User> users = User.getUsers();
        long totalDoctors = users.stream().filter(u -> u instanceof Doctor).count();
        long totalPatients = users.stream().filter(u -> u instanceof Patient).count();
        long totalAdmins = users.stream().filter(u -> u instanceof Administrator).count();

        statsPanel.add(createStatCard("Total Doctors", String.valueOf(totalDoctors), "👨‍⚕️"));
        statsPanel.add(createStatCard("Total Patients", String.valueOf(totalPatients), "👥"));
        statsPanel.add(createStatCard("Total Admins", String.valueOf(totalAdmins), "👨‍💼"));
        statsPanel.add(createStatCard("Total Users", String.valueOf(users.size()), "👤"));

        panel.add(welcomePanel, BorderLayout.NORTH);
        panel.add(statsPanel, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createStatCard(String title, String value, String icon) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(200, 200, 200)),
            new EmptyBorder(20, 20, 20, 20)
        ));

        JLabel iconLabel = new JLabel(icon);
        iconLabel.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        valueLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        titleLabel.setForeground(new Color(100, 100, 100));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        card.add(iconLabel);
        card.add(Box.createVerticalStrut(10));
        card.add(valueLabel);
        card.add(Box.createVerticalStrut(5));
        card.add(titleLabel);

        return card;
    }

    private JPanel createUserManagementPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        // Create split pane
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(250);
        splitPane.setOpaque(false);

        // Left panel - User list
        JPanel leftPanel = new JPanel(new BorderLayout(10, 10));
        leftPanel.setBackground(Color.WHITE);
        leftPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(200, 200, 200)),
            new EmptyBorder(20, 20, 20, 20)
        ));

        // Search section
        JPanel searchPanel = new JPanel(new BorderLayout(10, 10));
        searchPanel.setBackground(Color.WHITE);
        JLabel searchLabel = new JLabel("Search Users");
        searchLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        JTextField searchField = new JTextField();
        searchField.setPreferredSize(new Dimension(200, 30));
        searchField.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(200, 200, 200)),
            new EmptyBorder(5, 10, 5, 10)
        ));
        searchPanel.add(searchLabel, BorderLayout.NORTH);
        searchPanel.add(searchField, BorderLayout.CENTER);
        leftPanel.add(searchPanel, BorderLayout.NORTH);

        // User list
        userListModel = new DefaultListModel<>();
        userList = new JList<>(userListModel);
        userList.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        userList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        userList.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                    boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof User) {
                    User user = (User) value;
                    String role = user instanceof Doctor ? "Dr. " : "";
                    setText(role + user.getName());
                    setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
                    if (isSelected) {
                        setBackground(new Color(66, 139, 202));
                        setForeground(Color.WHITE);
                    } else {
                        setBackground(Color.WHITE);
                        setForeground(Color.BLACK);
                    }
                }
                return this;
            }
        });
        JScrollPane listScrollPane = new JScrollPane(userList);
        listScrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        leftPanel.add(listScrollPane, BorderLayout.CENTER);

        // User count
        JLabel userCountLabel = new JLabel("Total Users: " + User.getUsers().size());
        userCountLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        userCountLabel.setForeground(new Color(100, 100, 100));
        leftPanel.add(userCountLabel, BorderLayout.SOUTH);

        // Right panel - User details and actions
        JPanel rightPanel = new JPanel(new BorderLayout(10, 10));
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(200, 200, 200)),
            new EmptyBorder(20, 20, 20, 20)
        ));

        // User details section
        JPanel detailsPanel = new JPanel(new BorderLayout(10, 10));
        detailsPanel.setBackground(Color.WHITE);
        JLabel detailsLabel = new JLabel("User Details");
        detailsLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        detailsPanel.add(detailsLabel, BorderLayout.NORTH);

        userDetailsArea = new JTextArea();
        userDetailsArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        userDetailsArea.setEditable(false);
        userDetailsArea.setLineWrap(true);
        userDetailsArea.setWrapStyleWord(true);
        JScrollPane detailsScrollPane = new JScrollPane(userDetailsArea);
        detailsScrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        detailsPanel.add(detailsScrollPane, BorderLayout.CENTER);
        rightPanel.add(detailsPanel, BorderLayout.CENTER);

        // Action buttons
        JPanel actionButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        actionButtons.setBackground(Color.WHITE);

        JButton addUserBtn = createModernButton("Add User", new Color(66, 139, 202), "Add new user");
        JButton editUserBtn = createModernButton("Edit User", new Color(255, 152, 0), "Edit selected user");
        JButton deleteUserBtn = createModernButton("Delete User", new Color(244, 67, 54), "Delete selected user");

        addUserBtn.addActionListener(e -> showAddUserDialog());
        editUserBtn.addActionListener(e -> {
            User selectedUser = userList.getSelectedValue();
            if (selectedUser != null) {
                showEditUserDialog(selectedUser);
            } else {
                JOptionPane.showMessageDialog(this,
                    "Please select a user to edit.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        deleteUserBtn.addActionListener(e -> {
            User selectedUser = userList.getSelectedValue();
            if (selectedUser != null) {
                int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete this user?",
                    "Confirm Deletion",
                    JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    deleteUserFromDatabase(selectedUser);
                    loadUsersFromDatabase();
                }
            } else {
                JOptionPane.showMessageDialog(this,
                    "Please select a user to delete.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });

        actionButtons.add(addUserBtn);
        actionButtons.add(editUserBtn);
        actionButtons.add(deleteUserBtn);
        rightPanel.add(actionButtons, BorderLayout.SOUTH);

        // Add panels to split pane
        splitPane.setLeftComponent(leftPanel);
        splitPane.setRightComponent(rightPanel);

        // Add user selection listener
        userList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                User selectedUser = userList.getSelectedValue();
                if (selectedUser != null) {
                    updateUserDetails(selectedUser);
                }
            }
        });

        // Add search functionality
        searchField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void changedUpdate(javax.swing.event.DocumentEvent e) { filterUsers(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { filterUsers(); }
            public void insertUpdate(javax.swing.event.DocumentEvent e) { filterUsers(); }

            private void filterUsers() {
                String searchText = searchField.getText().toLowerCase();
                userListModel.clear();
                for (User user : User.getUsers()) {
                    if (user.getName().toLowerCase().contains(searchText)) {
                        userListModel.addElement(user);
                    }
                }
            }
        });

        // Initial load of users
        loadUsersFromDatabase();

        panel.add(splitPane, BorderLayout.CENTER);
        return panel;
    }

    private void loadUsersFromDatabase() {
        userListModel.clear();
        try {
            String query = "SELECT * FROM users";
            ResultSet rs = MDBS.DB_Connector.executeQuery(query);
            while (rs != null && rs.next()) {
                int userId = rs.getInt("user_id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                String phone = rs.getString("phone");
                String password = rs.getString("password");
                String userType = rs.getString("user_type");
                if (userType.equals("DOCTOR")) {
                    // Get specialization
                    String specQuery = "SELECT specialization FROM doctors WHERE doctor_id = " + userId;
                    ResultSet specRs = MDBS.DB_Connector.executeQuery(specQuery);
                    String specialization = specRs != null && specRs.next() ? specRs.getString("specialization") : "";
                    userListModel.addElement(new Doctor(userId, name, email, phone, password, specialization));
                } else if (userType.equals("PATIENT")) {
                    // Get patient details
                    String patQuery = "SELECT dob, gender, emergency_contact, primary_doctor_id FROM patients WHERE patient_id = " + userId;
                    ResultSet patRs = MDBS.DB_Connector.executeQuery(patQuery);
                    String dob = "", emergencyContact = ""; char gender = ' '; Doctor primaryDoctor = null;
                    if (patRs != null && patRs.next()) {
                        dob = patRs.getString("dob");
                        gender = patRs.getString("gender").charAt(0);
                        emergencyContact = patRs.getString("emergency_contact");
                        int docId = patRs.getInt("primary_doctor_id");
                        if (docId > 0) {
                            // Fetch doctor for primaryDoctor
                            String docQuery = "SELECT name, email, phone, password FROM users WHERE user_id = " + docId;
                            ResultSet docRs = MDBS.DB_Connector.executeQuery(docQuery);
                            if (docRs != null && docRs.next()) {
                                primaryDoctor = new Doctor(docId, docRs.getString("name"), docRs.getString("email"), docRs.getString("phone"), docRs.getString("password"), "");
                            }
                        }
                    }
                    userListModel.addElement(new Patient(userId, name, email, phone, password, dob, gender, emergencyContact, primaryDoctor));
                } else if (userType.equals("ADMIN")) {
                    userListModel.addElement(new Administrator(userId, name, email, phone, password));
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading users: " + e.getMessage());
        }
    }

    private void updateUserDetails(User user) {
        StringBuilder details = new StringBuilder();
        details.append("Name: ").append(user.getName()).append("\n");
        details.append("Email: ").append(user.getEmail()).append("\n");
        details.append("Phone: ").append(user.getPhone()).append("\n");
        details.append("Role: ").append(getUserRole(user)).append("\n");
        
        if (user instanceof Doctor) {
            Doctor doctor = (Doctor) user;
            details.append("Specialization: ").append(doctor.getSpecialization()).append("\n");
            details.append("Patients: ").append(doctor.getPatients().size()).append("\n");
        } else if (user instanceof Patient) {
            Patient patient = (Patient) user;
            details.append("Age: ").append(patient.getAge()).append("\n");
            details.append("Gender: ").append(patient.getGender()).append("\n");
            details.append("Emergency Contact: ").append(patient.getEmergencyContact()).append("\n");
        }
        
        userDetailsArea.setText(details.toString());
    }

    private String getUserRole(User user) {
        if (user instanceof Doctor) return "Doctor";
        if (user instanceof Patient) return "Patient";
        if (user instanceof Administrator) return "Administrator";
        return "Unknown";
    }

    private JPanel createSystemLogsPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel logsPanel = new JPanel(new BorderLayout(10, 10));
        logsPanel.setBackground(Color.WHITE);
        logsPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(200, 200, 200)),
            new EmptyBorder(20, 20, 20, 20)
        ));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        JLabel headerLabel = new JLabel("System Logs");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        JLabel descLabel = new JLabel("View system activity and user actions");
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descLabel.setForeground(new Color(100, 100, 100));
        headerPanel.add(headerLabel, BorderLayout.NORTH);
        headerPanel.add(descLabel, BorderLayout.CENTER);
        logsPanel.add(headerPanel, BorderLayout.NORTH);

        // Logs content
        JTextArea logsArea = new JTextArea();
        logsArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        logsArea.setEditable(false);
        logsArea.setLineWrap(true);
        logsArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(logsArea);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        logsPanel.add(scrollPane, BorderLayout.CENTER);

        // Action buttons
        JPanel actionButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        actionButtons.setBackground(Color.WHITE);

        JButton refreshBtn = createModernButton("Refresh", new Color(100, 100, 100), "Update logs");
        refreshBtn.addActionListener(e -> {
            logsArea.setText("");
            // Add your log retrieval logic here
            logsArea.append("System Logs\n");
            logsArea.append("Last updated: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()) + "\n\n");
            logsArea.append("No logs available at the moment.\n");
        });

        actionButtons.add(refreshBtn);
        logsPanel.add(actionButtons, BorderLayout.SOUTH);

        panel.add(logsPanel, BorderLayout.CENTER);
        return panel;
    }

    private void showAddUserDialog() {
        JDialog dialog = new JDialog(this, "Add New User", true);
        dialog.setLayout(new BorderLayout(20, 20));
        dialog.getContentPane().setBackground(Color.WHITE);
        dialog.setPreferredSize(new Dimension(600, 600));

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.weightx = 1.0;

        int row = 0;
        // User type selection
        gbc.gridx = 0;
        gbc.gridy = row;
        formPanel.add(new JLabel("User Type:"), gbc);
        gbc.gridx = 1;
        String[] userTypes = {"Doctor", "Patient", "Administrator"};
        JComboBox<String> userTypeCombo = new JComboBox<>(userTypes);
        userTypeCombo.setPreferredSize(new Dimension(200, 30));
        formPanel.add(userTypeCombo, gbc);
        row++;

        // Name field
        gbc.gridx = 0;
        gbc.gridy = row;
        formPanel.add(new JLabel("Name:"), gbc);
        gbc.gridx = 1;
        JTextField nameField = new JTextField(20);
        nameField.setPreferredSize(new Dimension(200, 30));
        formPanel.add(nameField, gbc);
        row++;

        // Email field
        gbc.gridx = 0;
        gbc.gridy = row;
        formPanel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        JTextField emailField = new JTextField(20);
        emailField.setPreferredSize(new Dimension(200, 30));
        formPanel.add(emailField, gbc);
        row++;

        // Phone field
        gbc.gridx = 0;
        gbc.gridy = row;
        formPanel.add(new JLabel("Phone:"), gbc);
        gbc.gridx = 1;
        JTextField phoneField = new JTextField(20);
        phoneField.setPreferredSize(new Dimension(200, 30));
        formPanel.add(phoneField, gbc);
        row++;

        // Password field
        gbc.gridx = 0;
        gbc.gridy = row;
        formPanel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        JPasswordField passwordField = new JPasswordField(20);
        passwordField.setPreferredSize(new Dimension(200, 30));
        formPanel.add(passwordField, gbc);
        row++;

        // Specialization field (for doctors)
        gbc.gridx = 0;
        gbc.gridy = row;
        JLabel specializationLabel = new JLabel("Specialization:");
        formPanel.add(specializationLabel, gbc);
        gbc.gridx = 1;
        JTextField specializationField = new JTextField(20);
        specializationField.setPreferredSize(new Dimension(200, 30));
        formPanel.add(specializationField, gbc);
        row++;

        // Date of Birth field (for patients)
        gbc.gridx = 0;
        gbc.gridy = row;
        JLabel dobLabel = new JLabel("Date of Birth (YYYY-MM-DD):");
        formPanel.add(dobLabel, gbc);
        gbc.gridx = 1;
        JTextField dobField = new JTextField(20);
        dobField.setPreferredSize(new Dimension(200, 30));
        formPanel.add(dobField, gbc);
        row++;

        // Gender field (for patients)
        gbc.gridx = 0;
        gbc.gridy = row;
        JLabel genderLabel = new JLabel("Gender:");
        formPanel.add(genderLabel, gbc);
        gbc.gridx = 1;
        String[] genders = {"M", "F"};
        JComboBox<String> genderCombo = new JComboBox<>(genders);
        genderCombo.setPreferredSize(new Dimension(200, 30));
        formPanel.add(genderCombo, gbc);
        row++;

        // Emergency Contact field (for patients)
        gbc.gridx = 0;
        gbc.gridy = row;
        JLabel emergencyLabel = new JLabel("Emergency Contact:");
        formPanel.add(emergencyLabel, gbc);
        gbc.gridx = 1;
        JTextField emergencyField = new JTextField(20);
        emergencyField.setPreferredSize(new Dimension(200, 30));
        formPanel.add(emergencyField, gbc);
        row++;

        // Primary Doctor field (for patients)
        gbc.gridx = 0;
        gbc.gridy = row;
        JLabel doctorLabel = new JLabel("Primary Doctor:");
        formPanel.add(doctorLabel, gbc);
        gbc.gridx = 1;
        JComboBox<Doctor> doctorCombo = new JComboBox<>();
        doctorCombo.setPreferredSize(new Dimension(200, 30));
        // Populate doctor combo box from database (unique doctors only)
        try {
            String query = "SELECT u.user_id, u.name, u.email, u.phone, u.password, d.specialization FROM users u JOIN doctors d ON u.user_id = d.doctor_id";
            ResultSet rs = MDBS.DB_Connector.executeQuery(query);
            while (rs != null && rs.next()) {
                int userId = rs.getInt("user_id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                String phone = rs.getString("phone");
                String password = rs.getString("password");
                String specialization = rs.getString("specialization");
                doctorCombo.addItem(new Doctor(userId, name, email, phone, password, specialization));
            }
        } catch (Exception ex) {
            // Optionally show error
            ex.printStackTrace(); // VERY IMPORTANT: Print the stack trace for debugging
            JOptionPane.showMessageDialog(dialog, "Error loading doctors: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);

        }
        // Set a custom renderer for the doctor combo box
        doctorCombo.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Doctor) {
                    Doctor doctor = (Doctor) value;
                    setText("Dr. " + doctor.getName() + " (" + doctor.getSpecialization() + ")");
                }
                return this;
            }
        });
        formPanel.add(doctorCombo, gbc);
        row++;

        // Show/hide fields based on user type
        userTypeCombo.addActionListener(e -> {
            String selectedUserType = (String) userTypeCombo.getSelectedItem(); // Get selected item
            boolean isDoctor = selectedUserType.equals("Doctor");
            boolean isPatient = selectedUserType.equals("Patient");
            specializationLabel.setVisible(isDoctor);
            specializationField.setVisible(isDoctor);
            dobLabel.setVisible(isPatient);
            dobField.setVisible(isPatient);
            genderLabel.setVisible(isPatient);
            genderCombo.setVisible(isPatient);
            emergencyLabel.setVisible(isPatient);
            emergencyField.setVisible(isPatient);
            doctorLabel.setVisible(isPatient);
            doctorCombo.setVisible(isPatient);
            dialog.pack(); //resize
        });
        // Initially hide all type-specific fields
        specializationLabel.setVisible(false);
        specializationField.setVisible(false);
        dobLabel.setVisible(false);
        dobField.setVisible(false);
        genderLabel.setVisible(false);
        genderCombo.setVisible(false);
        emergencyLabel.setVisible(false);
        emergencyField.setVisible(false);
        doctorLabel.setVisible(false);
        doctorCombo.setVisible(false);

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(Color.WHITE);
        JButton addBtn = createModernButton("Add User", new Color(66, 139, 202), "Create new user");
        JButton cancelBtn = createModernButton("Cancel", new Color(100, 100, 100), "Close dialog");

        addBtn.addActionListener(e -> {
            String name = nameField.getText();
            String email = emailField.getText();
            String phone = phoneField.getText();
            String password = new String(passwordField.getPassword());
            String userType = (String) userTypeCombo.getSelectedItem();

            if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(dialog,
                        "Please fill in all required fields.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                //  REMOVE BCRYPT HASHING - THIS IS INSECURE!
                String storedPassword = password;  // Store plain text password
                User newUser = null;
                switch (userType) {
                    case "Doctor":
                        String specialization = specializationField.getText();
                        if (specialization.isEmpty()) {
                            JOptionPane.showMessageDialog(dialog,
                                    "Please enter specialization for doctor.",
                                    "Error",
                                    JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                        String doctorInsertQuery = "INSERT INTO users (name, email, phone, password, user_type) VALUES (?, ?, ?, ?, 'DOCTOR')";
                        PreparedStatement doctorPs = MDBS.DB_Connector.getConnection().prepareStatement(doctorInsertQuery, Statement.RETURN_GENERATED_KEYS);
                        doctorPs.setString(1, name);
                        doctorPs.setString(2, email);
                        doctorPs.setString(3, phone);
                        doctorPs.setString(4, storedPassword);  // Store plain text
                        doctorPs.executeUpdate();
                        ResultSet generatedKeysDoctor = doctorPs.getGeneratedKeys();
                        int newUserId = 0;
                        if (generatedKeysDoctor.next()) {
                            newUserId = generatedKeysDoctor.getInt(1);
                        }
                        doctorPs.close();

                        String specializationInsertQuery = "INSERT INTO doctors (doctor_id, specialization) VALUES (?, ?)";
                        PreparedStatement specializationPs = MDBS.DB_Connector.getConnection().prepareStatement(specializationInsertQuery);
                        specializationPs.setInt(1, newUserId);
                        specializationPs.setString(2, specialization);
                        specializationPs.executeUpdate();
                        specializationPs.close();
                        newUser = new Doctor(newUserId, name, email, phone, storedPassword, specialization); // Use storedPassword
                        break;
                    case "Patient":
                        String dob = dobField.getText();
                        String gender = (String) genderCombo.getSelectedItem();
                        String emergencyContact = emergencyField.getText();
                        Doctor selectedDoctor = (Doctor) doctorCombo.getSelectedItem();
                        int primaryDoctorId = (selectedDoctor != null) ? selectedDoctor.getUserId() : 0;

                        if (dob.isEmpty() || gender.isEmpty() || emergencyContact.isEmpty()) {
                            JOptionPane.showMessageDialog(dialog,
                                    "Please fill in all patient-specific fields.",
                                    "Error",
                                    JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                        String patientInsertQuery = "INSERT INTO users (name, email, phone, password, user_type) VALUES (?, ?, ?, ?, 'PATIENT')";
                        PreparedStatement patientPs = MDBS.DB_Connector.getConnection().prepareStatement(patientInsertQuery, Statement.RETURN_GENERATED_KEYS);
                        patientPs.setString(1, name);
                        patientPs.setString(2, email);
                        patientPs.setString(3, phone);
                        patientPs.setString(4, storedPassword);  // Store plain text
                        patientPs.executeUpdate();
                        ResultSet generatedKeysPatient = patientPs.getGeneratedKeys();
                        newUserId = 0;
                        if (generatedKeysPatient.next()) {
                            newUserId = generatedKeysPatient.getInt(1);
                        }
                        patientPs.close();

                        String patientDetailsInsertQuery = "INSERT INTO patients (patient_id, dob, gender, emergency_contact, primary_doctor_id) VALUES (?, ?, ?, ?, ?)";
                        PreparedStatement patientDetailsPs = MDBS.DB_Connector.getConnection().prepareStatement(patientDetailsInsertQuery);
                        patientDetailsPs.setInt(1, newUserId);
                        patientDetailsPs.setString(2, dob);
                        patientDetailsPs.setString(3, gender);
                        patientDetailsPs.setString(4, emergencyContact);
                        patientDetailsPs.setInt(5, primaryDoctorId);
                        patientDetailsPs.executeUpdate();
                        patientDetailsPs.close();
                        newUser = new Patient(newUserId, name, email, phone, storedPassword, dob, gender.charAt(0), emergencyContact, selectedDoctor); // Use storedPassword
                        break;
                    case "Administrator":
                        String adminInsertQuery = "INSERT INTO users (name, email, phone, password, user_type) VALUES (?, ?, ?, ?, 'ADMIN')";
                        PreparedStatement adminPs = MDBS.DB_Connector.getConnection().prepareStatement(adminInsertQuery, Statement.RETURN_GENERATED_KEYS);
                        adminPs.setString(1, name);
                        adminPs.setString(2, email);
                        adminPs.setString(3, phone);
                        adminPs.setString(4, storedPassword);  // Store plain text
                        adminPs.executeUpdate();
                        ResultSet generatedKeysAdmin = adminPs.getGeneratedKeys();
                        newUserId = 0;
                        if (generatedKeysAdmin.next()) {
                            newUserId = generatedKeysAdmin.getInt(1);
                        }
                        adminPs.close();
                        newUser = new Administrator(newUserId, name, email, phone, storedPassword); // Use storedPassword
                        break;
                }

                User.addUser(newUser);
                loadUsersFromDatabase();
                dialog.dispose();
                statusLabel.setText("User added successfully.");

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog,
                        "Error adding user: " + ex.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                statusLabel.setText("Error adding user.");
                ex.printStackTrace(); //  Print the exception's stack trace.

            }
        });

        cancelBtn.addActionListener(e -> dialog.dispose());

        buttonPanel.add(addBtn);
        buttonPanel.add(cancelBtn);

        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void showEditUserDialog(User user) {
        JDialog dialog = new JDialog(this, "Edit User", true);
        dialog.setLayout(new BorderLayout(20, 20));
        dialog.getContentPane().setBackground(Color.WHITE);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        // Name field
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Name:"), gbc);
        gbc.gridx = 1;
        JTextField nameField = new JTextField(user.getName(), 20);
        nameField.setPreferredSize(new Dimension(200, 30));
        formPanel.add(nameField, gbc);

        // Email field
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        JTextField emailField = new JTextField(user.getEmail(), 20);
        emailField.setPreferredSize(new Dimension(200, 30));
        formPanel.add(emailField, gbc);

        // Phone field
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Phone:"), gbc);
        gbc.gridx = 1;
        JTextField phoneField = new JTextField(user.getPhone(), 20);
        phoneField.setPreferredSize(new Dimension(200, 30));
        formPanel.add(phoneField, gbc);

        // Specialization field (for doctors)
        if (user instanceof Doctor) {
            Doctor doctor = (Doctor) user;
            gbc.gridx = 0; gbc.gridy = 3;
            formPanel.add(new JLabel("Specialization:"), gbc);
            gbc.gridx = 1;
            JTextField specializationField = new JTextField(doctor.getSpecialization(), 20);
            specializationField.setPreferredSize(new Dimension(200, 30));
            formPanel.add(specializationField, gbc);
        }

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(Color.WHITE);
        JButton saveBtn = createModernButton("Save Changes", new Color(66, 139, 202), "Update user information");
        JButton cancelBtn = createModernButton("Cancel", new Color(100, 100, 100), "Close dialog");

        saveBtn.addActionListener(e -> {
            String name = nameField.getText();
            String email = emailField.getText();
            String phone = phoneField.getText();

            if (name.isEmpty() || email.isEmpty() || phone.isEmpty()) {
                JOptionPane.showMessageDialog(dialog,
                    "Please fill in all required fields.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }

            user.setName(name);
            user.setEmail(email);
            user.setPhone(phone);

            if (user instanceof Doctor) {
                Doctor doctor = (Doctor) user;
                JTextField specializationField = (JTextField) formPanel.getComponent(7);
                doctor.setSpecialization(specializationField.getText());
            }

            updateUserInDatabase(user);
            dialog.dispose();
            JOptionPane.showMessageDialog(this,
                "User updated successfully.",
                "Success",
                JOptionPane.INFORMATION_MESSAGE);
        });

        cancelBtn.addActionListener(e -> dialog.dispose());

        buttonPanel.add(saveBtn);
        buttonPanel.add(cancelBtn);

        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void addUserToDatabase(User user) {
        try {
            String userType = user instanceof Doctor ? "DOCTOR" : user instanceof Patient ? "PATIENT" : "ADMIN";
            String query = String.format(
                "INSERT INTO users (name, email, phone, password, user_type) VALUES ('%s', '%s', '%s', '%s', '%s')",
                user.getName(), user.getEmail(), user.getPhone(), user.getPassword(), userType
            );
            MDBS.DB_Connector.executeUpdate(query);
            // Get the new user_id
            ResultSet rs = MDBS.DB_Connector.executeQuery("SELECT LAST_INSERT_ID() as id");
            int userId = rs != null && rs.next() ? rs.getInt("id") : -1;
            if (user instanceof Doctor) {
                Doctor d = (Doctor) user;
                String docQuery = String.format("INSERT INTO doctors (doctor_id, specialization) VALUES (%d, '%s')", userId, d.getSpecialization());
                MDBS.DB_Connector.executeUpdate(docQuery);
            } else if (user instanceof Patient) {
                Patient p = (Patient) user;
                int primaryDoctorId = p.getPrimaryDoctor() != null ? p.getPrimaryDoctor().getUserId() : 0;
                String patQuery = String.format(
                    "INSERT INTO patients (patient_id, dob, gender, emergency_contact, primary_doctor_id) VALUES (%d, '%s', '%c', '%s', %d)",
                    userId, p.getDob(), p.getGender(), p.getEmergencyContact(), primaryDoctorId
                );
                MDBS.DB_Connector.executeUpdate(patQuery);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error adding user: " + e.getMessage());
        }
    }

    private void updateUserInDatabase(User user) {
        try {
            String query = String.format(
                "UPDATE users SET name='%s', email='%s', phone='%s', password='%s' WHERE user_id=%d",
                user.getName(), user.getEmail(), user.getPhone(), user.getPassword(), user.getUserId()
            );
            MDBS.DB_Connector.executeUpdate(query);
            if (user instanceof Doctor) {
                Doctor d = (Doctor) user;
                String docQuery = String.format("UPDATE doctors SET specialization='%s' WHERE doctor_id=%d", d.getSpecialization(), user.getUserId());
                MDBS.DB_Connector.executeUpdate(docQuery);
            } else if (user instanceof Patient) {
                Patient p = (Patient) user;
                int primaryDoctorId = p.getPrimaryDoctor() != null ? p.getPrimaryDoctor().getUserId() : 0;
                String patQuery = String.format(
                    "UPDATE patients SET dob='%s', gender='%c', emergency_contact='%s', primary_doctor_id=%d WHERE patient_id=%d",
                    p.getDob(), p.getGender(), p.getEmergencyContact(), primaryDoctorId, user.getUserId()
                );
                MDBS.DB_Connector.executeUpdate(patQuery);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error updating user: " + e.getMessage());
        }
    }

    private void deleteUserFromDatabase(User user) {
        try {
            if (user instanceof Doctor) {
                MDBS.DB_Connector.executeUpdate("DELETE FROM doctors WHERE doctor_id=" + user.getUserId());
            } else if (user instanceof Patient) {
                MDBS.DB_Connector.executeUpdate("DELETE FROM patients WHERE patient_id=" + user.getUserId());
            }
            MDBS.DB_Connector.executeUpdate("DELETE FROM users WHERE user_id=" + user.getUserId());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error deleting user: " + e.getMessage());
        }
    }

    private JButton createModernButton(String text, Color color, String tooltip) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(color);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(180, 40));
        button.setToolTipText(tooltip);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(color.darker());
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(color);
            }
        });

        return button;
    }

    private void handleLogout() {
        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to logout?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION
        );
        
        if (confirm == JOptionPane.YES_OPTION) {
            this.dispose();
            loginFrame.setVisible(true);
        }
    }
    private void displayUserDetails(User user) {
        String details = "User ID: " + user.getUserId() + "\n" +
                "Name: " + user.getName() + "\n" +
                "Email: " + user.getEmail() + "\n" +
                "Phone: " + user.getPhone() + "\n";
        userDetailsArea.setText(details);
    }
}
