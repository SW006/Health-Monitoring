package GUI_INterface;

import Emergency_Alert_System.PanicButton;
import Health_Data_Handling.VitalSign;
import Notification_and_Reminder.ReminderService;
import User_Management.Patient;
import User_Management.Doctor;
import Doctor_Patient_Interaction.Feedback;
import Doctor_Patient_Interaction.Prescription;
import Appointment_Scheduling.AppointmentManager;
import Appointment_Scheduling.Appointment;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


public class PatientDashboard extends JFrame {
    private Patient patient;
    private LoginFrame loginFrame;
    private AppointmentManager appointmentManager;
    private JPanel mainPanel;
    private CardLayout cardLayout;
    private JTextArea historyTextArea;
    private JTextArea appointmentsTextArea;
    private JLabel welcomeLabel;
    private JLabel statusLabel;
    private JList<String> appointmentsList;
    private DefaultListModel<String> appointmentsListModel;
    private JList<String> prescriptionsList;
    private DefaultListModel<String> prescriptionsListModel;
    private JPanel statsPanel;
    private String uploadedFilePath = "";
    private ReminderService reminderService;
    private PanicButton panicButton;
    private JTextArea remindersTextArea;


    public PatientDashboard(Patient patient, LoginFrame loginFrame,ReminderService reminderService, PanicButton panicButton)
    {

        this.patient = patient;
        this.loginFrame = loginFrame;
        this.appointmentManager = AppointmentManager.getInstance();
        this.reminderService = reminderService;
        this.panicButton = panicButton;
        this.cardLayout = new CardLayout();

        initializeUI();
    }

    private void initializeUI() {
        setTitle("Patient Dashboard - " + patient.getName());
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main panel with gradient background
        mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                int w = getWidth();
                int h = getHeight();
                Color color1 = new Color(66, 139, 202);
                Color color2 = new Color(255, 255, 255);
                GradientPaint gp = new GradientPaint(0, 0, color1, w, h, color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, w, h);
            }
        };
        mainPanel.setLayout(cardLayout);

        // Create and add panels
        mainPanel.add(createDashboardPanel(), "DASHBOARD");
        mainPanel.add(createMedicalHistoryPanel(), "MEDICAL_HISTORY");
        mainPanel.add(createAppointmentsPanel(), "APPOINTMENTS");
        mainPanel.add(createPrescriptionsPanel(), "PRESCRIPTIONS");
        mainPanel.add(createVitalsPanel(), "VITALS");

        // Create sidebar
        JPanel sidebar = createSidebar();

        // Main layout
        setLayout(new BorderLayout());
        add(sidebar, BorderLayout.WEST);
        add(mainPanel, BorderLayout.CENTER);

        // Show dashboard by default
        cardLayout.show(mainPanel, "DASHBOARD");
        setVisible(true);
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(51, 51, 51));
        sidebar.setPreferredSize(new Dimension(200, 0));
        sidebar.setBorder(new EmptyBorder(20, 10, 20, 10));

        // Add user info at top
        JPanel userPanel = new JPanel();
        userPanel.setLayout(new BoxLayout(userPanel, BoxLayout.Y_AXIS));
        userPanel.setBackground(new Color(51, 51, 51));
        userPanel.setBorder(new EmptyBorder(0, 0, 20, 0));

        JLabel nameLabel = new JLabel(patient.getName());
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        nameLabel.setForeground(Color.WHITE);
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel roleLabel = new JLabel("Patient");
        roleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        roleLabel.setForeground(new Color(200, 200, 200));
        roleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        userPanel.add(nameLabel);
        userPanel.add(Box.createVerticalStrut(5));
        userPanel.add(roleLabel);
        sidebar.add(userPanel);
        sidebar.add(Box.createVerticalStrut(20));

        // Navigation buttons
        String[] navItems = {"Dashboard", "Medical History", "Appointments", "Prescriptions","Vitals"};
        for (String item : navItems) {
            JButton navButton = createNavButton(item);
            sidebar.add(navButton);
            sidebar.add(Box.createVerticalStrut(10));
        }

        // Logout button at bottom
        JButton logoutButton = createNavButton("Logout");
        logoutButton.setForeground(new Color(255, 100, 100));
        logoutButton.addActionListener(e -> handleLogout());
        sidebar.add(Box.createVerticalGlue());
        sidebar.add(logoutButton);

        return sidebar;
    }

    private JButton createNavButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(51, 51, 51));
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setMaximumSize(new Dimension(180, 40));
        button.setPreferredSize(new Dimension(180, 40));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addActionListener(e -> {
            cardLayout.show(mainPanel, text.toUpperCase().replace(" ", "_"));
        });

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(new Color(70, 70, 70));
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(new Color(51, 51, 51));
            }
        });

        return button;
    }

    private JPanel createDashboardPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        // Welcome section
        JPanel welcomePanel = new JPanel(new BorderLayout());
        welcomePanel.setBackground(Color.WHITE);
        welcomePanel.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(200, 200, 200)),
                new EmptyBorder(20, 20, 20, 20)
        ));

        welcomeLabel = new JLabel("Welcome back, " + patient.getName());
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        welcomePanel.add(welcomeLabel, BorderLayout.WEST);

        // Stats grid
        statsPanel = new JPanel(new GridLayout(2, 2, 20, 20));
        statsPanel.setOpaque(false);

        updateDashboardStats();

        panel.add(welcomePanel, BorderLayout.NORTH);

        // Add the content panel here - This will contain reminders and emergency button
        panel.add(createContentPanel(), BorderLayout.SOUTH); // Or BorderLayout.CENTER, adjust as needed

        return panel;
    }

    private void updateDashboardStats() {
        statsPanel.removeAll();

        List<Appointment> appointments = appointmentManager.getPatientAppointments(patient);
        long upcomingAppointments = appointments.stream()
                .filter(a -> a.getStatus().equals("SCHEDULED"))
                .count();
        long completedAppointments = appointments.stream()
                .filter(a -> a.getStatus().equals("COMPLETED"))
                .count();

        List<Prescription> prescriptions = appointmentManager.getPrescriptionList(patient);
        long totalPrescriptions = prescriptions.size();

        statsPanel.add(createStatCard("Upcoming Appointments", String.valueOf(upcomingAppointments), "📅"));
        statsPanel.add(createStatCard("Completed Appointments", String.valueOf(completedAppointments), "✅"));
        statsPanel.add(createStatCard("Prescriptions", String.valueOf(totalPrescriptions), "💊"));
        statsPanel.add(createStatCard("Medical Records", String.valueOf(patient.getFeedbacks().size()), "📋"));

        statsPanel.revalidate();
        statsPanel.repaint();
    }

    private JPanel createStatCard(String title, String value, String icon) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(200, 200, 200)),
                new EmptyBorder(20, 20, 20, 20)
        ));

        JLabel iconLabel = new JLabel(icon);
        iconLabel.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        valueLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        titleLabel.setForeground(new Color(100, 100, 100));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        card.add(iconLabel);
        card.add(Box.createVerticalStrut(10));
        card.add(valueLabel);
        card.add(Box.createVerticalStrut(5));
        card.add(titleLabel);

        return card;
    }

    private JPanel createMedicalHistoryPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel historyPanel = new JPanel(new BorderLayout(10, 10));
        historyPanel.setBackground(Color.WHITE);
        historyPanel.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(200, 200, 200)),
                new EmptyBorder(20, 20, 20, 20)
        ));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        JLabel headerLabel = new JLabel("Medical History");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        JLabel descLabel = new JLabel("View your medical records, prescriptions, and history");
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descLabel.setForeground(new Color(100, 100, 100));
        headerPanel.add(headerLabel, BorderLayout.NORTH);
        headerPanel.add(descLabel, BorderLayout.CENTER);
        historyPanel.add(headerPanel, BorderLayout.NORTH);

        // Medical history content
        JTextArea historyArea = new JTextArea();
        historyArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        historyArea.setEditable(false);
        historyArea.setLineWrap(true);
        historyArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(historyArea);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        historyPanel.add(scrollPane, BorderLayout.CENTER);

        // Action buttons
        JPanel actionButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        actionButtons.setBackground(Color.WHITE);

        JButton refreshBtn = createModernButton("Refresh", new Color(100, 100, 100), "Update medical history");
        refreshBtn.addActionListener(e -> {
            historyArea.setText("");

            // Display Prescriptions
            historyArea.append("=== PRESCRIPTIONS ===\n\n");
            List<Prescription> prescriptions = appointmentManager.getPrescriptionList(patient);
            if (prescriptions != null && !prescriptions.isEmpty()) {
                for (Prescription prescription : prescriptions) {
                    historyArea.append("Date: " + new SimpleDateFormat("yyyy-MM-dd").format(new Date()) + "\n");
                    historyArea.append("Doctor: Dr. " + prescription.getDoctor().getName() + "\n");
                    historyArea.append("Medication: " + prescription.getMedication() + "\n");
                    historyArea.append("Dosage: " + prescription.getDosage() + "\n");
                    historyArea.append("Instructions: " + prescription.getInstructions() + "\n\n");
                }
            } else {
                historyArea.append("No prescriptions found.\n\n");
            }

            // Display Medical Feedback
            historyArea.append("=== MEDICAL FEEDBACK ===\n\n");
            List<Feedback> feedbacks = appointmentManager.getFeedbackList(patient);
            if (feedbacks != null && !feedbacks.isEmpty()) {
                for (Feedback feedback : feedbacks) {
                    historyArea.append("Date: " + new SimpleDateFormat("yyyy-MM-dd").format(feedback.getDate()) + "\n");
                    historyArea.append("Doctor: Dr. " + feedback.getDoctor().getName() + "\n");
                    historyArea.append("Feedback: " + feedback.getFeedbackText() + "\n\n");
                }
            } else {
                historyArea.append("No medical feedback found.\n\n");
            }
        });

        actionButtons.add(refreshBtn);
        historyPanel.add(actionButtons, BorderLayout.SOUTH);

        // Initial load of medical history
        refreshBtn.doClick();

        panel.add(historyPanel, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createAppointmentsPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel appointmentsPanel = new JPanel(new BorderLayout(10, 10));
        appointmentsPanel.setBackground(Color.WHITE);
        appointmentsPanel.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(200, 200, 200)),
                new EmptyBorder(20, 20, 20, 20)
        ));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        JLabel headerLabel = new JLabel("My Appointments");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        JLabel descLabel = new JLabel("View and manage your appointments");
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descLabel.setForeground(new Color(100, 100, 100));
        headerPanel.add(headerLabel, BorderLayout.NORTH);
        headerPanel.add(descLabel, BorderLayout.CENTER);
        appointmentsPanel.add(headerPanel, BorderLayout.NORTH);

        // Appointments list
        JPanel listPanel = new JPanel(new BorderLayout(10, 10));
        listPanel.setBackground(Color.WHITE);
        appointmentsListModel = new DefaultListModel<>();
        appointmentsList = new JList<>(appointmentsListModel);
        appointmentsList.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(appointmentsList);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        listPanel.add(scrollPane, BorderLayout.CENTER);
        appointmentsPanel.add(listPanel, BorderLayout.CENTER);

        // Action buttons
        JPanel actionButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        actionButtons.setBackground(Color.WHITE);

        JButton refreshBtn = createModernButton("Refresh", new Color(100, 100, 100), "Update appointments list");
        JButton scheduleBtn = createModernButton("Schedule Appointment", new Color(66, 139, 202), "Book new appointment");
        JButton cancelBtn = createModernButton("Cancel Appointment", new Color(244, 67, 54), "Cancel selected appointment");

        refreshBtn.addActionListener(e -> {
            updateAppointmentsList();
            updateDashboardStats();
        });
        scheduleBtn.addActionListener(e -> showScheduleAppointmentDialog());
        cancelBtn.addActionListener(e -> {
            int index = appointmentsList.getSelectedIndex();
            if (index != -1) {
                List<Appointment> appointments = appointmentManager.getPatientAppointments(patient);
                if (index < appointments.size()) {
                    Appointment appointment = appointments.get(index);
                    if (!appointment.getStatus().equals("COMPLETED")) {
                        int confirm = JOptionPane.showConfirmDialog(this,
                                "Are you sure you want to cancel this appointment?",
                                "Confirm Cancellation",
                                JOptionPane.YES_NO_OPTION);
                        if (confirm == JOptionPane.YES_OPTION) {
                            appointmentManager.cancelAppointment(appointment);
                            updateAppointmentsList();
                            updateDashboardStats();
                        }
                    } else {
                        JOptionPane.showMessageDialog(this,
                                "Cannot cancel a completed appointment.",
                                "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this,
                        "Please select an appointment to cancel.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        actionButtons.add(refreshBtn);
        actionButtons.add(scheduleBtn);
        actionButtons.add(cancelBtn);
        appointmentsPanel.add(actionButtons, BorderLayout.SOUTH);

        // Initial load of appointments
        updateAppointmentsList();

        panel.add(appointmentsPanel, BorderLayout.CENTER);
        return panel;
    }

    private void updateAppointmentsList() {
        appointmentsListModel.clear();
        List<Appointment> appointments = appointmentManager.getPatientAppointments(patient);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        for (Appointment appointment : appointments) {
            appointmentsListModel.addElement(String.format("%s - %s - %s",
                    dateFormat.format(appointment.getDate()),
                    appointment.getDoctor().getName(),
                    appointment.getStatus()));
        }
    }

//    private JButton createModernButton(String text, Color color, String tooltip) {
//        JButton button = new JButton(text);
//        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
//        button.setForeground(Color.WHITE);
//        button.setBackground(color);
//        button.setFocusPainted(false);
//        button.setBorderPainted(false);
//        button.setPreferredSize(new Dimension(180, 40));
//        button.setToolTipText(tooltip);
//        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
//
//        button.addMouseListener(new java.awt.event.MouseAdapter() {
//            public void mouseEntered(java.awt.event.MouseEvent evt) {
//                button.setBackground(color.darker());
//            }
//
//            public void mouseExited(java.awt.event.MouseEvent evt) {
//                button.setBackground(color);
//            }
//        });
//
//        return button;
//    }



//    private JPanel createVitalsPanel() {
//        JPanel panel = new JPanel(new BorderLayout(20, 20));
//        panel.setOpaque(false);
//        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
//
//        JPanel vitalsPanel = new JPanel(new BorderLayout(10, 10));
//        vitalsPanel.setBackground(Color.WHITE);
//        vitalsPanel.setBorder(BorderFactory.createCompoundBorder(
//                new LineBorder(new Color(200, 200, 200)),
//                new EmptyBorder(20, 20, 20, 20)
//        ));
//
//        // Header
//        JPanel headerPanel = new JPanel(new BorderLayout());
//        headerPanel.setBackground(Color.WHITE);
//        JLabel headerLabel = new JLabel("Vitals Monitoring");
//        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
//        JLabel descLabel = new JLabel("Upload and view your health vitals from a CSV file.");
//        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
//        descLabel.setForeground(new Color(100, 100, 100));
//        headerPanel.add(headerLabel, BorderLayout.NORTH);
//        headerPanel.add(descLabel, BorderLayout.CENTER);
//        vitalsPanel.add(headerPanel, BorderLayout.NORTH);
//
//        // Buttons
//        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));
//        actionPanel.setBackground(Color.WHITE);
//
//        JButton uploadBtn = createModernButton("Upload Vitals CSV", new Color(66, 139, 202), "Import vitals data");
//        JButton chartBtn = createModernButton("Show Vitals Chart", new Color(76, 175, 80), "View vitals as a line chart");
//
//        uploadBtn.addActionListener(e -> {
//            JFileChooser chooser = new JFileChooser();
//            int result = chooser.showOpenDialog(this);
//            if (result == JFileChooser.APPROVE_OPTION) {
//                File csvFile = chooser.getSelectedFile();
//                try {
//                    // Ensure table exists
//                    Health_Data_Handling.VitalSign.createTable();
//
//                    // Load vitals from CSV file
//                    Health_Data_Handling.VitalSign.loadFromCSV(new File(csvFile.getAbsolutePath()));
//
//                    JOptionPane.showMessageDialog(this, "Vitals imported successfully.");
//                } catch (SQLException ex) {
//                    JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "SQL Error", JOptionPane.ERROR_MESSAGE);
//                    ex.printStackTrace();
//                } catch (IOException ex) {
//                    JOptionPane.showMessageDialog(this, "Failed to read CSV file: " + ex.getMessage(), "IO Error", JOptionPane.ERROR_MESSAGE);
//                    ex.printStackTrace();
//                } catch (Exception ex) {
//                    JOptionPane.showMessageDialog(this, "Unexpected error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
//                    ex.printStackTrace();
//                }
//            }
//        });
//
//        chartBtn.addActionListener(e -> {
//            try {
//                JFreeChart chart = Health_Data_Handling.VitalSign.getLineChart(); // You should have this method implemented
//                ChartPanel chartPanel = new ChartPanel(chart);
//                JFrame chartFrame = new JFrame("Vital Signs Line Chart");
//                chartFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//                chartFrame.add(chartPanel);
//                chartFrame.pack();
//                chartFrame.setLocationRelativeTo(this);
//                chartFrame.setVisible(true);
//            } catch (Exception ex) {
//                JOptionPane.showMessageDialog(this, "Unable to display chart: " + ex.getMessage(), "Chart Error", JOptionPane.ERROR_MESSAGE);
//                ex.printStackTrace();
//            }
//        });
//
//        actionPanel.add(uploadBtn);
//        actionPanel.add(chartBtn);
//        vitalsPanel.add(actionPanel, BorderLayout.CENTER);
//        panel.add(vitalsPanel, BorderLayout.CENTER);
//        return panel;
//    }



    private JPanel createPrescriptionsPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel prescriptionsPanel = new JPanel(new BorderLayout(10, 10));
        prescriptionsPanel.setBackground(Color.WHITE);
        prescriptionsPanel.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(200, 200, 200)),
                new EmptyBorder(20, 20, 20, 20)
        ));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        JLabel headerLabel = new JLabel("Current Prescriptions");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        JLabel descLabel = new JLabel("View your active prescriptions from your doctor");
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descLabel.setForeground(new Color(100, 100, 100));
        headerPanel.add(headerLabel, BorderLayout.NORTH);
        headerPanel.add(descLabel, BorderLayout.CENTER);
        prescriptionsPanel.add(headerPanel, BorderLayout.NORTH);

        // Prescriptions list
        JPanel listPanel = new JPanel(new BorderLayout(10, 10));
        listPanel.setBackground(Color.WHITE);
        prescriptionsListModel = new DefaultListModel<>();
        prescriptionsList = new JList<>(prescriptionsListModel);
        prescriptionsList.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        prescriptionsList.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                          boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof String) {
                    setText("<html>" + ((String) value).replace("\n", "<br>") + "</html>");
                }
                return this;
            }
        });
        JScrollPane scrollPane = new JScrollPane(prescriptionsList);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        listPanel.add(scrollPane, BorderLayout.CENTER);
        prescriptionsPanel.add(listPanel, BorderLayout.CENTER);

        // Action buttons
        JPanel actionButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        actionButtons.setBackground(Color.WHITE);

        JButton refreshBtn = createModernButton("Refresh", new Color(100, 100, 100), "Update prescriptions list");
        refreshBtn.addActionListener(e -> {
            updatePrescriptionsList();
            updateDashboardStats();
        });

        actionButtons.add(refreshBtn);
        prescriptionsPanel.add(actionButtons, BorderLayout.SOUTH);

        // Initial load of prescriptions
        updatePrescriptionsList();

        panel.add(prescriptionsPanel, BorderLayout.CENTER);
        return panel;
    }

    private void updatePrescriptionsList() {
        prescriptionsListModel.clear();
        List<Prescription> prescriptions = appointmentManager.getPrescriptionList(patient);
        if (prescriptions != null && !prescriptions.isEmpty()) {
            for (Prescription prescription : prescriptions) {
                String prescriptionText = String.format(
                        "Date: %s\nDoctor: Dr. %s\nMedication: %s\nDosage: %s\nInstructions: %s",
                        new SimpleDateFormat("yyyy-MM-dd").format(new Date()),
                        prescription.getDoctor().getName(),
                        prescription.getMedication(),
                        prescription.getDosage(),
                        prescription.getInstructions()
                );
                prescriptionsListModel.addElement(prescriptionText);
            }
        } else {
            prescriptionsListModel.addElement("No active prescriptions found.");
        }
    }

    private void handleLogout() {
        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to logout?",
                "Confirm Logout",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm == JOptionPane.YES_OPTION) {
            this.dispose();
            loginFrame.setVisible(true);
        }
    }
    private void showScheduleAppointmentDialog() {
        JDialog dialog = new JDialog(this, "Schedule Appointment", true);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.getContentPane().setBackground(Color.WHITE);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        // === Date field ===
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Date (YYYY-MM-DD):"), gbc);
        gbc.gridx = 1;
        JTextField dateField = new JTextField(20);
        formPanel.add(dateField, gbc);

        // === Time field ===
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Time (HH:MM):"), gbc);
        gbc.gridx = 1;
        JTextField timeField = new JTextField(20);
        formPanel.add(timeField, gbc);

        // === Doctor Dropdown ===
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Select Doctor:"), gbc);
        gbc.gridx = 1;

        AppointmentManager manager = AppointmentManager.getInstance();
        List<Doctor> doctorList = manager.getAllDoctors();

        if (doctorList.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No doctors available to schedule.");
            return;
        }

        JComboBox<Doctor> doctorComboBox = new JComboBox<>(doctorList.toArray(new Doctor[0]));
        doctorComboBox.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                          boolean isSelected, boolean cellHasFocus) {
                if (value instanceof Doctor) {
                    Doctor doctor = (Doctor) value;
                    value = "Dr. " + doctor.getName() + " (" + doctor.getSpecialization() + ")";
                }
                return super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            }
        });
        formPanel.add(doctorComboBox, gbc);

        // === Buttons ===
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(Color.WHITE);

        JButton scheduleBtn = new JButton("Schedule");
        JButton cancelBtn = new JButton("Cancel");

        scheduleBtn.addActionListener(e -> {
            String date = dateField.getText().trim();
            String time = timeField.getText().trim();
            Doctor selectedDoctor = (Doctor) doctorComboBox.getSelectedItem();

            if (date.isEmpty() || time.isEmpty() || selectedDoctor == null) {
                JOptionPane.showMessageDialog(dialog, "Please complete all fields.");
                return;
            }

            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                sdf.setLenient(false);
                Date appointmentDateTime = sdf.parse(date + " " + time);

                Appointment appointment = manager.scheduleAppointment(patient, selectedDoctor, appointmentDateTime);

                if (appointment != null) {
                    JOptionPane.showMessageDialog(dialog,
                            "Appointment scheduled with Dr. " + selectedDoctor.getName() +
                                    " on " + new SimpleDateFormat("yyyy-MM-dd").format(appointmentDateTime));
                    dialog.dispose();
                    updateAppointmentsList();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Failed to schedule. Time slot may be taken.");
                }

            } catch (ParseException ex) {
                JOptionPane.showMessageDialog(dialog,
                        "Invalid format.\nUse Date: YYYY-MM-DD and Time: HH:MM (24hr format).",
                        "Format Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        cancelBtn.addActionListener(e -> dialog.dispose());

        buttonPanel.add(scheduleBtn);
        buttonPanel.add(cancelBtn);

        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }
    private JPanel createVitalsPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel vitalsPanel = new JPanel(new BorderLayout(10, 10));
        vitalsPanel.setBackground(Color.WHITE);
        vitalsPanel.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(200, 200, 200)),
                new EmptyBorder(20, 20, 20, 20)
        ));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        JLabel headerLabel = new JLabel("Vitals Monitoring");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        JLabel descLabel = new JLabel("Upload and view your health vitals from a CSV file.");
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descLabel.setForeground(new Color(100, 100, 100));
        headerPanel.add(headerLabel, BorderLayout.NORTH);
        headerPanel.add(descLabel, BorderLayout.CENTER);
        vitalsPanel.add(headerPanel, BorderLayout.NORTH);

        // Buttons
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));
        actionPanel.setBackground(Color.WHITE);

        JButton uploadBtn = createModernButton("Upload Vitals CSV", new Color(66, 139, 202), "Import vitals data");
        JButton chartBtn = createModernButton("Show Vitals Chart", new Color(76, 175, 80), "View vitals as a line chart");

        // Use a final variable to make patientId accessible in the listeners
        final int finalPatientId = patient.getUserId();  // Store patientId in a final variable
        uploadBtn.addActionListener(e -> uploadCSV(mainPanel, finalPatientId));
        chartBtn.addActionListener(e -> showVitalChart(mainPanel, finalPatientId));

        actionPanel.add(uploadBtn);
        actionPanel.add(chartBtn);
        vitalsPanel.add(actionPanel, BorderLayout.CENTER);
        panel.add(vitalsPanel, BorderLayout.CENTER);
        return panel;
    }

    private JButton createModernButton(String text, Color background, String toolTipText) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(background);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setToolTipText(toolTipText);

        // Add hover effect
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(background.darker()); // Slightly darken the color
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(background);
            }
        });
        return button;
    }
    private void uploadCSV(JPanel parent, int patientId) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select a CSV File");
        fileChooser.setFileFilter(new FileNameExtensionFilter("CSV Files", "csv"));

        int result = fileChooser.showOpenDialog(parent);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try {
                // Load vitals from CSV file, passing the patient ID
                VitalSign.createTable();
                VitalSign.loadFromCSV(selectedFile, patientId);
                JOptionPane.showMessageDialog(parent, "Vitals imported successfully for patient ID: " + patientId);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(parent, "Database error: " + ex.getMessage(), "SQL Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(parent, "Failed to read CSV file: " + ex.getMessage(), "IO Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            } catch (ParseException ex) {
                JOptionPane.showMessageDialog(parent, "Error parsing CSV data: " + ex.getMessage(), "Parse Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(parent, "Unexpected error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        }
    }

    private void showVitalChart(JPanel parent, int patientId) {
        try {
            //  Generate the chart, passing the patient ID
            JFreeChart chart = VitalSign.getLineChart(patientId);
            ChartPanel chartPanel = new ChartPanel(chart);
            JFrame chartFrame = new JFrame("Vital Signs Line Chart - Patient ID: " + patientId);
            chartFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            chartFrame.add(chartPanel);
            chartFrame.pack();
            chartFrame.setLocationRelativeTo(parent);
            chartFrame.setVisible(true);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(parent, "Error generating chart: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(parent, "Unexpected error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    private JPanel createContentPanel() {
        JPanel contentPanel = new JPanel(new GridLayout(2, 1));
        contentPanel.add(createRemindersPanel());
        contentPanel.add(createEmergencyPanel());
        return contentPanel;
    }

    private JPanel createRemindersPanel() {
        JPanel remindersPanel = new JPanel(new BorderLayout(10, 10));
        remindersPanel.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(200, 200, 200)),
                new EmptyBorder(20, 20, 20, 20)
        ));

        JLabel remindersLabel = new JLabel("Your Reminders");
        remindersLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        remindersPanel.add(remindersLabel, BorderLayout.NORTH);

        remindersTextArea = new JTextArea();
        remindersTextArea.setEditable(false);
        JScrollPane remindersScrollPane = new JScrollPane(remindersTextArea);
        remindersPanel.add(remindersScrollPane, BorderLayout.CENTER);

        // Display reminders when the panel is created
        displayReminders();

        return remindersPanel;
    }

    private JPanel createEmergencyPanel() {
        JPanel emergencyPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));
        emergencyPanel.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(200, 200, 200)),
                new EmptyBorder(20, 20, 20, 20)
        ));

        JButton panicButtonUI = new JButton("Press for Emergency");
        panicButtonUI.setFont(new Font("Segoe UI", Font.BOLD, 16));
        panicButtonUI.setBackground(new Color(255, 0, 0));
        panicButtonUI.setForeground(Color.WHITE);
        panicButtonUI.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panicButton.press();
                JOptionPane.showMessageDialog(mainPanel, "Emergency alert sent!");
            }
        });
        emergencyPanel.add(panicButtonUI);
        return emergencyPanel;
    }

    private void displayReminders() {
        // Fetch reminders from the database using reminderService
        List<String> appointmentReminders = reminderService.getAppointmentReminders(patient.getUserId());
        List<String> medicationReminders = reminderService.getMedicationReminders(patient.getUserId());

        remindersTextArea.setText("");
        if (appointmentReminders != null && !appointmentReminders.isEmpty()) {
            remindersTextArea.append("Appointments:\n");
            for (String reminder : appointmentReminders) {
                remindersTextArea.append("- " + reminder + "\n");
            }
        }
        if (medicationReminders != null && !medicationReminders.isEmpty()) {
            remindersTextArea.append("\nMedications:\n");
            for (String reminder : medicationReminders) {
                remindersTextArea.append("- " + reminder + "\n");
            }
        }
        if ((appointmentReminders == null || appointmentReminders.isEmpty()) && (medicationReminders == null || medicationReminders.isEmpty())) {
            remindersTextArea.append("No reminders at this time.\n");
        }
    }






}