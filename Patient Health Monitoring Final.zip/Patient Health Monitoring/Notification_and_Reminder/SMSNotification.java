package Notification_and_Reminder;

// SMSNotification
public class SMSNotification implements Notifiable {
    @Override
    public void sendNotification(String recipient, String message) {
        System.out.println("=== SMS NOTIFICATION ===");
        System.out.println("To: " + recipient);
        System.out.println("Message: " + message);
        System.out.println("=======================");
    }
}