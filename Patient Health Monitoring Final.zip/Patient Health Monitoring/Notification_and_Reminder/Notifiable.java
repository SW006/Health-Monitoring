package Notification_and_Reminder;

public interface Notifiable {
    void sendNotification(String recipient, String message);
}