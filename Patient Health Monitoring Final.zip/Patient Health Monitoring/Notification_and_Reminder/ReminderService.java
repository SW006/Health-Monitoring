package Notification_and_Reminder;

import MDBS.DB_Connector;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class ReminderService {
    private Notifiable notificationService;

    public ReminderService(Notifiable notificationService) {
        this.notificationService = notificationService;
    }

    public void sendAppointmentReminder(String recipient, String appointmentDetails) {
        String message = "Appointment Reminder: " + appointmentDetails;
        notificationService.sendNotification(recipient, message);
    }

    public void sendMedicationReminder(String recipient, String medicationDetails) {
        String message = "Medication Reminder: " + medicationDetails;
        notificationService.sendNotification(recipient, message);
    }

    // New methods to get reminders from the database
    public List<String> getAppointmentReminders(int patientId) {
        return getRemindersFromDB(patientId, "Appointment");
    }

    public List<String> getMedicationReminders(int patientId) {
        return getRemindersFromDB(patientId, "Medication");
    }

    private List<String> getRemindersFromDB(int patientId, String reminderType) {
        List<String> reminders = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = DB_Connector.getConnection();
            String sql = "SELECT reminder_text, reminder_time FROM Reminders " +
                    "WHERE patient_id = ? AND reminder_type = ? AND reminder_time > NOW() ORDER BY reminder_time";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, patientId);
            pstmt.setString(2, reminderType);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                String reminderText = rs.getString("reminder_text");
                Timestamp reminderTime = rs.getTimestamp("reminder_time");
                reminders.add(reminderText + " (Time: " + reminderTime + ")");
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Log the error
            // Consider throwing the exception or returning an empty list
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return reminders;
    }
}

