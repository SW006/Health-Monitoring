package Notification_and_Reminder;

import User_Management.Patient;
import User_Management.User;

public class EmailNotification implements Notifiable {
    private final String senderEmail;
    private final String senderPassword;

    // Constructor that takes email credentials
    public EmailNotification(String senderEmail, String senderPassword) {
        this.senderEmail = senderEmail;
        this.senderPassword = senderPassword;
    }

    @Override
    public void sendNotification(String recipientEmail, String message) {
        try {
            // For now, just print the message to console
            System.out.println("Email would be sent to: " + recipientEmail);
            System.out.println("Message: " + message);
            System.out.println("Note: Email functionality is currently disabled. Please add jakarta.mail-2.0.1.jar to your project dependencies.");
        } catch (Exception e) {
            System.out.println("Failed to send email notification to " + recipientEmail + ": " + e.getMessage());
        }
    }

    // Convenience method that takes a User object
    public void sendNotification(User recipient, String message) {
        sendNotification(recipient.getEmail(), message);
    }
}

