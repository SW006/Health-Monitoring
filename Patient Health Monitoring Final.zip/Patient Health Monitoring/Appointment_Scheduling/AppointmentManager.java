package Appointment_Scheduling;

import User_Management.Patient;
import User_Management.Doctor;
import Doctor_Patient_Interaction.MedicalHistory;
import Doctor_Patient_Interaction.Feedback;
import Doctor_Patient_Interaction.Prescription;
import MDBS.DB_Connector;

import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.text.SimpleDateFormat;

public class AppointmentManager {
    private static AppointmentManager instance;
    private ArrayList<MedicalHistory> medicalHistories;
    private ArrayList<Feedback> feedbacks;
    private ArrayList<Prescription> prescriptions;

    private AppointmentManager() {
        this.medicalHistories = new ArrayList<>();
        this.feedbacks = new ArrayList<>();
        this.prescriptions = new ArrayList<>();
    }

    public static AppointmentManager getInstance() {
        if (instance == null) {
            instance = new AppointmentManager();
        }
        return instance;
    }

    public void assignPatientToDoctor(Patient patient, Doctor doctor) {
        if (!doctor.getPatients().contains(patient)) {
            doctor.addPatient(patient);
            patient.setPrimaryDoctor(doctor);
        }
    }

    public Appointment scheduleAppointment(Patient patient, Doctor doctor, Date date) {
        try {
            // First ensure the patient is assigned to the doctor
            assignPatientToDoctor(patient, doctor);

            // Check for conflicting appointments
            if (hasAppointmentConflict(doctor, date)) {
                return null;
            }

            // Insert appointment into database
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String query = String.format(
                    "INSERT INTO appointments (patient_id, doctor_id, appointment_date, status) " +
                            "VALUES (%d, %d, '%s', 'SCHEDULED')",
                    patient.getUserId(), doctor.getUserId(), sdf.format(date)
            );

            int result = DB_Connector.executeUpdate(query);
            if (result > 0) {
                // Get the generated appointment ID
                ResultSet rs = DB_Connector.executeQuery("SELECT LAST_INSERT_ID()");
                if (rs != null && rs.next()) {
                    int appointmentId = rs.getInt(1);
                    return new Appointment(appointmentId, patient, doctor, date);
                }
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void cancelAppointment(Appointment appointment) {
        if (appointment != null) {
            String query = String.format(
                    "UPDATE appointments SET status = 'CANCELLED' WHERE appointment_id = %d",
                    appointment.getAppointmentId()
            );
            DB_Connector.executeUpdate(query);
            appointment.cancelAppointment();
        }
    }

    public void completeAppointment(Appointment appointment) {
        if (appointment != null) {
            String query = String.format(
                    "UPDATE appointments SET status = 'COMPLETED' WHERE appointment_id = %d",
                    appointment.getAppointmentId()
            );
            DB_Connector.executeUpdate(query);
            appointment.completeAppointment();
        }
    }

    public List<Appointment> getDoctorAppointments(Doctor doctor) {
        List<Appointment> appointments = new ArrayList<>();
        String query = String.format(
                "SELECT a.*, u.name as patient_name, u.email as patient_email, u.phone as patient_phone " +
                        "FROM appointments a " +
                        "JOIN users u ON a.patient_id = u.user_id " +
                        "WHERE a.doctor_id = %d " +
                        "ORDER BY a.appointment_date DESC",
                doctor.getUserId()
        );

        ResultSet rs = DB_Connector.executeQuery(query);
        try {
            while (rs != null && rs.next()) {
                Patient patient = new Patient(
                        rs.getInt("patient_id"),
                        rs.getString("patient_name"),
                        rs.getString("patient_email"),
                        rs.getString("patient_phone"),
                        "", // password not needed
                        "", // dob not needed
                        ' ', // gender not needed
                        "", // emergency contact not needed
                        doctor
                );
                Appointment appointment = new Appointment(
                        rs.getInt("appointment_id"),
                        patient,
                        doctor,
                        rs.getTimestamp("appointment_date")
                );
                appointment.setStatus(rs.getString("status"));
                appointments.add(appointment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return appointments;
    }

    public List<Appointment> getPatientAppointments(Patient patient) {
        List<Appointment> appointments = new ArrayList<>();
        String query = String.format(
                "SELECT a.*, u.name as doctor_name, u.email as doctor_email, u.phone as doctor_phone, d.specialization " +
                        "FROM appointments a " +
                        "JOIN users u ON a.doctor_id = u.user_id " +
                        "JOIN doctors d ON u.user_id = d.doctor_id " +
                        "WHERE a.patient_id = %d " +
                        "ORDER BY a.appointment_date DESC",
                patient.getUserId()
        );

        ResultSet rs = DB_Connector.executeQuery(query);
        try {
            while (rs != null && rs.next()) {
                Doctor doctor = new Doctor(
                        rs.getInt("doctor_id"),
                        rs.getString("doctor_name"),
                        rs.getString("doctor_email"),
                        rs.getString("doctor_phone"),
                        "", // password not needed
                        rs.getString("specialization")
                );
                Appointment appointment = new Appointment(
                        rs.getInt("appointment_id"),
                        patient,
                        doctor,
                        rs.getTimestamp("appointment_date")
                );
                appointment.setStatus(rs.getString("status"));
                appointments.add(appointment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return appointments;
    }

    public List<Appointment> getTodayAppointments(Doctor doctor) {
        List<Appointment> appointments = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String today = sdf.format(new Date());

        String query = String.format(
                "SELECT a.*, u.name as patient_name, u.email as patient_email, u.phone as patient_phone " +
                        "FROM appointments a " +
                        "JOIN users u ON a.patient_id = u.user_id " +
                        "WHERE a.doctor_id = %d " +
                        "AND DATE(a.appointment_date) = '%s' " +
                        "AND a.status != 'CANCELLED'",
                doctor.getUserId(), today
        );

        ResultSet rs = DB_Connector.executeQuery(query);
        try {
            while (rs != null && rs.next()) {
                Patient patient = new Patient(
                        rs.getInt("patient_id"),
                        rs.getString("patient_name"),
                        rs.getString("patient_email"),
                        rs.getString("patient_phone"),
                        "", // password not needed
                        "", // dob not needed
                        ' ', // gender not needed
                        "", // emergency contact not needed
                        doctor
                );
                appointments.add(new Appointment(
                        rs.getInt("appointment_id"),
                        patient,
                        doctor,
                        rs.getTimestamp("appointment_date")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return appointments;
    }

    public List<Appointment> getPendingAppointments(Doctor doctor) {
        List<Appointment> appointments = new ArrayList<>();
        String query = String.format(
                "SELECT a.*, u.name as patient_name, u.email as patient_email, u.phone as patient_phone " +
                        "FROM appointments a " +
                        "JOIN users u ON a.patient_id = u.user_id " +
                        "WHERE a.doctor_id = %d " +
                        "AND a.status = 'SCHEDULED'",
                doctor.getUserId()
        );

        ResultSet rs = DB_Connector.executeQuery(query);
        try {
            while (rs != null && rs.next()) {
                Patient patient = new Patient(
                        rs.getInt("patient_id"),
                        rs.getString("patient_name"),
                        rs.getString("patient_email"),
                        rs.getString("patient_phone"),
                        "", // password not needed
                        "", // dob not needed
                        ' ', // gender not needed
                        "", // emergency contact not needed
                        doctor
                );
                appointments.add(new Appointment(
                        rs.getInt("appointment_id"),
                        patient,
                        doctor,
                        rs.getTimestamp("appointment_date")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return appointments;
    }

    public boolean hasAppointmentConflict(Doctor doctor, Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String query = String.format(
                "SELECT COUNT(*) as count FROM appointments " +
                        "WHERE doctor_id = %d " +
                        "AND appointment_date = '%s' " +
                        "AND status != 'CANCELLED'",
                doctor.getUserId(), sdf.format(date)
        );

        ResultSet rs = DB_Connector.executeQuery(query);
        try {
            if (rs != null && rs.next()) {
                return rs.getInt("count") > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public void rescheduleAppointment(Appointment appointment, Date newDate) {
        if (appointment != null && !hasAppointmentConflict(appointment.getDoctor(), newDate)) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String query = String.format(
                    "UPDATE appointments SET appointment_date = '%s', status = 'SCHEDULED' " +
                            "WHERE appointment_id = %d",
                    sdf.format(newDate), appointment.getAppointmentId()
            );
            DB_Connector.executeUpdate(query);
            appointment.rescheduleAppointment(newDate);
        }
    }

    public List<Appointment> getAppointmentsByDate(Doctor doctor, Date date) {
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        cal1.setTime(date);

        return getDoctorAppointments(doctor).stream()
                .filter(apt -> {
                    cal2.setTime(apt.getDate());
                    return apt.getDoctor().equals(doctor) &&
                            cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                            cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR);
                })
                .collect(Collectors.toList());
    }

    public void listAppointments() {
        if (getDoctorAppointments(null).isEmpty()) {
            System.out.println("No appointments scheduled.");
            return;
        }

        for (Appointment a : getDoctorAppointments(null)) {
            a.displayDetails();
        }
    }

    // Medical History Management
    public MedicalHistory getMedicalHistory(Patient patient) {
        MedicalHistory history = new MedicalHistory(patient);

        try {
            String query = String.format(
                    "SELECT mh.*, u.name as doctor_name " +
                            "FROM medical_history mh " +
                            "JOIN users u ON mh.doctor_id = u.user_id " +
                            "WHERE mh.patient_id = %d " +
                            "ORDER BY mh.created_at DESC",
                    patient.getUserId()
            );

            ResultSet rs = DB_Connector.executeQuery(query);
            while (rs != null && rs.next()) {
                history.addDiagnosis(rs.getString("diagnosis"));
                history.addTreatment(rs.getString("treatment"));
                history.addNotes(rs.getString("notes"));
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving medical history: " + e.getMessage());
            e.printStackTrace();
        }

        return history;
    }

    public void addFeedback(Patient patient, Doctor doctor, String feedbackText) {
        Feedback feedback = new Feedback(feedbackText, new Date());
        feedbacks.add(feedback);
        getMedicalHistory(patient).addFeedback(feedback);
    }

    public void addPrescription(Patient patient, Doctor doctor, String medication, String dosage, String instructions) {
        try {
            String query = String.format(
                    "INSERT INTO prescriptions (patient_id, doctor_id, medication, dosage, instructions, prescribed_date) " +
                            "VALUES (%d, %d, '%s', '%s', '%s', CURDATE())",
                    patient.getUserId(), doctor.getUserId(), medication, dosage, instructions
            );
            DB_Connector.executeUpdate(query);
        } catch (Exception e) {
            System.err.println("Failed to add prescription to database: " + e.getMessage());
        }
    }

    public void addMedicalHistory(Patient patient, Doctor doctor, String diagnosis, String treatment, String notes) {
        try {
            String query = String.format(
                    "INSERT INTO medical_history (patient_id, doctor_id, diagnosis, treatment, notes, created_at) " +
                            "VALUES (%d, %d, '%s', '%s', '%s', NOW())",
                    patient.getUserId(), doctor.getUserId(), diagnosis, treatment, notes
            );

            int result = DB_Connector.executeUpdate(query);
            if (result > 0) {
                MedicalHistory history = getMedicalHistory(patient);
                history.addDiagnosis(diagnosis);
                history.addTreatment(treatment);
                history.addNotes(notes);
                System.out.println("Medical history added successfully for patient: " + patient.getName());
            } else {
                System.out.println("Failed to add medical history to database");
            }
        } catch (Exception e) {
            System.out.println("Error adding medical history: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public List<Feedback> getFeedbackList(Patient patient) {
        return getMedicalHistory(patient).getFeedbacks();
    }

    public List<Prescription> getPrescriptionList(Patient patient) {
        List<Prescription> prescriptions = new ArrayList<>();
        try {
            String query = String.format(
                    "SELECT p.*, u.name as doctor_name, u.email as doctor_email, u.phone as doctor_phone, d.specialization " +
                            "FROM prescriptions p " +
                            "JOIN users u ON p.doctor_id = u.user_id " +
                            "JOIN doctors d ON u.user_id = d.doctor_id " +
                            "WHERE p.patient_id = %d " +
                            "ORDER BY p.prescribed_date DESC",
                    patient.getUserId()
            );
            ResultSet rs = DB_Connector.executeQuery(query);
            while (rs.next()) {
                Doctor doctor = new Doctor(
                        rs.getInt("doctor_id"),
                        rs.getString("doctor_name"),
                        rs.getString("doctor_email"),
                        rs.getString("doctor_phone"),
                        "", // password not needed
                        rs.getString("specialization")
                );
                Prescription prescription = new Prescription(
                        patient,
                        doctor,
                        rs.getString("medication"),
                        rs.getString("dosage"),
                        rs.getString("instructions")
                );
                prescription.setDate(rs.getDate("prescribed_date"));
                prescriptions.add(prescription);
            }
        } catch (Exception e) {
            System.err.println("Error getting prescription list: " + e.getMessage());
        }
        return prescriptions;
    }

    public List<Prescription> getDoctorPrescriptions(Doctor doctor) {
        List<Prescription> prescriptions = new ArrayList<>();
        try {
            String query = String.format(
                    "SELECT p.*, u.name as patient_name, u.email as patient_email, u.phone as patient_phone, " +
                            "u.dob, u.gender, u.emergency_contact " +
                            "FROM prescriptions p " +
                            "JOIN users u ON p.patient_id = u.user_id " +
                            "WHERE p.doctor_id = %d " +
                            "ORDER BY p.prescribed_date DESC",
                    doctor.getUserId()
            );
            ResultSet rs = DB_Connector.executeQuery(query);
            while (rs.next()) {
                Patient patient = new Patient(
                        rs.getInt("patient_id"),
                        rs.getString("patient_name"),
                        rs.getString("patient_email"),
                        rs.getString("patient_phone"),
                        "", // password not needed
                        rs.getString("dob"),
                        rs.getString("gender").charAt(0),
                        rs.getString("emergency_contact"),
                        doctor
                );
                Prescription prescription = new Prescription(
                        patient,
                        doctor,
                        rs.getString("medication"),
                        rs.getString("dosage"),
                        rs.getString("instructions")
                );
                prescription.setDate(rs.getDate("prescribed_date"));
                prescriptions.add(prescription);
            }
        } catch (Exception e) {
            System.err.println("Error getting doctor prescriptions: " + e.getMessage());
        }
        return prescriptions;
    }

    public void updateMedicalHistory(Patient patient, String notes) {
        try {
            String query = String.format(
                    "INSERT INTO medical_history (patient_id, doctor_id, notes, created_at) " +
                            "VALUES (%d, %d, '%s', NOW())",
                    patient.getUserId(), patient.getPrimaryDoctor().getUserId(), notes
            );

            int result = DB_Connector.executeUpdate(query);
            if (result > 0) {
                MedicalHistory history = getMedicalHistory(patient);
                history.addNotes(notes);
                System.out.println("Medical history updated successfully for patient: " + patient.getName());
            } else {
                System.out.println("Failed to update medical history in database");
            }
        } catch (Exception e) {
            System.out.println("Error updating medical history: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public List<Feedback> getDoctorFeedbacks(Doctor doctor) {
        return feedbacks.stream()
                .filter(f -> f.getDoctor().equals(doctor))
                .collect(Collectors.toList());
    }

    public void displayPatientMedicalHistory(Patient patient) {
        MedicalHistory history = getMedicalHistory(patient);
        history.displayMedicalHistory();
    }

    // Helper method to calculate patient age
    public int calculatePatientAge(Patient patient) {
        try {
            String dob = patient.getDob();
            String[] parts = dob.split("-");
            int birthYear = Integer.parseInt(parts[0]);
            Calendar now = Calendar.getInstance();
            int currentYear = now.get(Calendar.YEAR);
            return currentYear - birthYear;
        } catch (Exception e) {
            return 0;
        }
    }

    public List<Patient> getDoctorPatients(Doctor doctor) {
        return doctor.getPatients();
    }

    public void addPatientToDoctor(Patient patient, Doctor doctor) {
        assignPatientToDoctor(patient, doctor);
    }

    public void removePatientFromDoctor(Patient patient, Doctor doctor) {
        doctor.removePatient(patient);
        patient.setPrimaryDoctor(null);
    }

    public Doctor findDoctorByName(String name) {
        Connection connection = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Doctor doctor = null;

        try {
            // Establish database connection
            DatabaseMetaData ConnectionManager = null;
            connection = ConnectionManager.getConnection();

            // SQL query to find a doctor by name
            String query = "SELECT * FROM doctor JOIN user AS u USING(doctor_id) WHERE u.name =\n ?";
            stmt = connection.prepareStatement(query);
            stmt.setString(1, name);
            // Execute the query
            rs = stmt.executeQuery();

            // If a doctor is found, create the Doctor object
            if (rs.next()) {
                int userId = rs.getInt("userId");
                String doctorName = rs.getString("name");
                String email = rs.getString("email");
                String phone = rs.getString("phone");
                String password = rs.getString("password");
                String specialization = rs.getString("specialization");

                // Create a Doctor object with the retrieved data
                doctor = new Doctor(userId, doctorName, email, phone, password, specialization);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close all resources
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return doctor;

    }
    public List<Doctor> getAllDoctors() {
        List<Doctor> doctorList = new ArrayList<>();

        try {
            String query = "SELECT u.user_id, u.name, u.email, u.phone, u.password, d.specialization " +
                    "FROM users u " +
                    "JOIN doctors d ON u.user_id = d.doctor_id " +
                    "WHERE u.user_type = 'doctor'";

            ResultSet rs = DB_Connector.executeQuery(query);

            while (rs != null && rs.next()) {
                int userId = rs.getInt("user_id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                String phone = rs.getString("phone");
                String password = rs.getString("password");
                String specialization = rs.getString("specialization");

                Doctor doctor = new Doctor(userId, name, email, phone, password, specialization);
                doctorList.add(doctor);
            }
        } catch (Exception e) {
            e.printStackTrace(); // Consider logging this in real applications
        }

        return doctorList;
    }


}