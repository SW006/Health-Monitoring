package Appointment_Scheduling;

import User_Management.Doctor;
import User_Management.Patient;

import java.util.Date;

/**
 * Represents an appointment between a patient and a doctor.
 */
public class Appointment {
    private int appointmentId;
    private Patient patient;
    private Doctor doctor;
    private Date date;
    private String status; // Scheduled, Completed, Canceled

    /**
     * Creates a new Appointment.
     */
    public Appointment(int appointmentId, Patient patient, Doctor doctor, Date date) {
        this.appointmentId = appointmentId;
        this.patient = patient;
        this.doctor = doctor;
        this.date = date;
        this.status = "Scheduled";
    }

    /**
     * Cancels the appointment and updates its status.
     */
    public void cancelAppointment() {
        this.status = "Canceled";
        System.out.println("Appointment with Dr. " + doctor.getName() + " has been canceled.");
    }

    /**
     * Marks the appointment as completed.
     */
    public void completeAppointment() {
        this.status = "Completed";
        System.out.println("Appointment with Dr. " + doctor.getName() + " is completed.");
    }

    /**
     * Reschedules the appointment to a new date, unless it's already canceled.
     */
    public void rescheduleAppointment(Date newDate) {
        if (this.status.equals("Canceled")) {
            System.out.println("Cannot reschedule a canceled appointment.");
        } else {
            this.date = newDate;
            this.status = "Scheduled"; // Reset to scheduled
            System.out.println("Appointment rescheduled to: " + newDate);
        }
    }

    /**
     * Displays the appointment details to the console.
     */
    public void displayDetails() {
        System.out.println("----Appointment Details----\nAppointment ID: " + appointmentId + ", Patient: " + patient.getName() +
                ", Doctor: " + doctor.getName() + ", Date: " + date + ", Status: " + status);
    }

    /**
     * Getters
     */
    public int getAppointmentId() {
        return appointmentId;
    }

    public Patient getPatient() {
        return patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public Date getDate() {
        return date;
    }

    public String getStatus() {
        return status;
    }

    /**
     * Setters
     */
    public void setDate(Date date) {
        this.date = date;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Appointment that = (Appointment) o;
        return appointmentId == that.appointmentId;
    }

    @Override
    public int hashCode() {
        return appointmentId;
    }
}
