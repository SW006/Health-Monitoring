package Doctor_Patient_Interaction;

import User_Management.Patient;
import User_Management.Doctor;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.util.stream.Collectors;

public class MedicalHistory {
    private Patient patient;
    private List<String> diagnoses;
    private List<String> treatments;
    private List<String> notes;
    private List<Prescription> prescriptions;
    private List<Feedback> feedbacks;
    private Date lastUpdated;

    public MedicalHistory(Patient patient) {
        this.patient = patient;
        this.diagnoses = new ArrayList<>();
        this.treatments = new ArrayList<>();
        this.notes = new ArrayList<>();
        this.prescriptions = new ArrayList<>();
        this.feedbacks = new ArrayList<>();
        this.lastUpdated = new Date();
    }

    public void addDiagnosis(String diagnosis) {
        if (diagnosis != null && !diagnosis.trim().isEmpty()) {
            this.diagnoses.add(diagnosis);
        }
    }

    public void addTreatment(String treatment) {
        if (treatment != null && !treatment.trim().isEmpty()) {
            this.treatments.add(treatment);
        }
    }

    public void addNotes(String note) {
        if (note != null && !note.trim().isEmpty()) {
            this.notes.add(note);
        }
    }

    public void addPrescription(Prescription prescription) {
        if (prescription != null) {
            this.prescriptions.add(prescription);
        }
    }

    public void addFeedback(Feedback feedback) {
        if (feedback != null) {
            this.feedbacks.add(feedback);
        }
    }

    private void updateLastUpdated() {
        this.lastUpdated = new Date();
    }

    public String displayMedicalHistory() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Medical History ===\n\n");

        // Display diagnoses
        if (!diagnoses.isEmpty()) {
            sb.append("Diagnoses:\n");
            for (String diagnosis : diagnoses) {
                sb.append("- ").append(diagnosis).append("\n");
            }
            sb.append("\n");
        }

        // Display treatments
        if (!treatments.isEmpty()) {
            sb.append("Treatments:\n");
            for (String treatment : treatments) {
                sb.append("- ").append(treatment).append("\n");
            }
            sb.append("\n");
        }

        // Display notes
        if (!notes.isEmpty()) {
            sb.append("Notes:\n");
            for (String note : notes) {
                sb.append("- ").append(note).append("\n");
            }
            sb.append("\n");
        }

        // Display prescriptions
        if (!prescriptions.isEmpty()) {
            sb.append("Prescriptions:\n");
            for (Prescription prescription : prescriptions) {
                sb.append(prescription.toString()).append("\n\n");
            }
            sb.append("\n");
        }

        // Display feedback
        if (!feedbacks.isEmpty()) {
            sb.append("Feedback:\n");
            for (Feedback feedback : feedbacks) {
                sb.append("- ").append(feedback.getFeedback()).append("\n");
            }
        }

        return sb.toString();
    }

    public Patient getPatient() {
        return patient;
    }

    public List<String> getDiagnoses() {
        return new ArrayList<>(diagnoses);
    }

    public List<String> getTreatments() {
        return new ArrayList<>(treatments);
    }

    public List<String> getNotes() {
        return new ArrayList<>(notes);
    }

    public List<Prescription> getPrescriptions() {
        return new ArrayList<>(prescriptions);
    }

    public List<Feedback> getFeedbacks() {
        return new ArrayList<>(feedbacks);
    }

    public Date getLastUpdated() {
        return lastUpdated;
    }

    // New methods for feedback management
    public List<Feedback> getFeedbackList() {
        return new ArrayList<>(feedbacks);
    }

    public List<Feedback> getFeedbackByDoctor(Doctor doctor) {
        return feedbacks.stream()
            .filter(f -> f.getDoctor() != null && f.getDoctor().equals(doctor))
            .collect(Collectors.toList());
    }

    public List<Feedback> getFeedbackByDate(Date date) {
        return feedbacks.stream()
            .filter(f -> f.getDate() != null && f.getDate().equals(date))
            .collect(Collectors.toList());
    }

    public List<Feedback> getRecentFeedback(int count) {
        return feedbacks.stream()
            .sorted((f1, f2) -> f2.getDate().compareTo(f1.getDate()))
            .limit(count)
            .collect(Collectors.toList());
    }

    public boolean hasFeedback() {
        return !feedbacks.isEmpty();
    }

    public boolean hasPrescriptions() {
        return !prescriptions.isEmpty();
    }

    public boolean hasNotes() {
        return !notes.isEmpty();
    }

    @Override
    public String toString() {
        return String.format("""
            Medical History for %s
            Last Updated: %s
            Notes: %d
            Feedbacks: %d
            Prescriptions: %d
            """,
            patient.getName(),
            lastUpdated,
            notes.size(),
            feedbacks.size(),
            prescriptions.size()
        );
    }
}
