package Doctor_Patient_Interaction;

import User_Management.Doctor;
import User_Management.Patient;
import java.util.Date;
import java.text.SimpleDateFormat;

public class Feedback {
    private Patient patient;
    private Doctor doctor;
    private String feedbackText;
    private Date date;
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");

    public Feedback(Patient patient, Doctor doctor, String feedbackText) {
        this.patient = patient;
        this.doctor = doctor;
        this.feedbackText = feedbackText;
        this.date = new Date();
    }

    public Feedback(String feedbackText, Date date) {
        this.feedbackText = feedbackText;
        this.date = date;
    }

    public Patient getPatient() {
        return patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public String getFeedbackText() {
        return feedbackText;
    }

    public Date getDate() {
        return date;
    }

    public String getFeedback() {
        if (doctor != null && patient != null) {
            return String.format("[%s] Dr. %s - %s: %s", 
                dateFormat.format(date),
                doctor.getName(),
                patient.getName(),
                feedbackText);
        } else {
            return String.format("[%s] %s", 
                dateFormat.format(date),
                feedbackText);
        }
    }

    @Override
    public String toString() {
        return getFeedback();
    }
}

