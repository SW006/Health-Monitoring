package Doctor_Patient_Interaction;

import User_Management.Patient;
import User_Management.Doctor;
import java.util.Date;
import java.text.SimpleDateFormat;

public class Prescription {
    private Patient patient;
    private Doctor doctor;
    private String medication;
    private String dosage;
    private String instructions;
    private Date date;
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");

    // Full constructor
    public Prescription(Patient patient, Doctor doctor, String medication, String dosage, String instructions) {
        this.patient = patient;
        this.doctor = doctor;
        this.medication = medication;
        this.dosage = dosage;
        this.instructions = instructions;
        this.date = new Date();
    }

    // Simplified constructor for basic prescription creation
    public Prescription(String medication, String dosage, String instructions) {
        this.medication = medication;
        this.dosage = dosage;
        this.instructions = instructions;
        this.date = new Date();
    }

    // Getters
    public Patient getPatient() {
        return patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public String getMedication() {
        return medication;
    }

    public String getDosage() {
        return dosage;
    }

    public String getInstructions() {
        return instructions;
    }

    public Date getDate() {
        return date;
    }

    // Setters
    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public void setMedication(String medication) {
        this.medication = medication;
    }

    public void setDosage(String dosage) {
        this.dosage = dosage;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getPrescription() {
        StringBuilder sb = new StringBuilder();
        if (date != null) {
            sb.append("[").append(dateFormat.format(date)).append("] ");
        }
        
        if (doctor != null) {
            sb.append("Dr. ").append(doctor.getName());
        }
        
        if (patient != null) {
            sb.append(" - ").append(patient.getName());
        }
        
        sb.append("\nMedication: ").append(medication)
          .append("\nDosage: ").append(dosage)
          .append("\nInstructions: ").append(instructions);
        
        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Medication: ").append(medication)
          .append("\nDosage: ").append(dosage)
          .append("\nInstructions: ").append(instructions);
        
        if (doctor != null) {
            sb.append("\nPrescribed by: Dr. ").append(doctor.getName());
        }
        
        if (date != null) {
            sb.append("\nDate: ").append(dateFormat.format(date));
        }
        
        return sb.toString();
    }
}
