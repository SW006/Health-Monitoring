package User_Management;

import java.util.ArrayList;
import java.util.List;

abstract public class User {
    protected int userId;
    protected String name;
    protected String email;
    protected String phone;
    protected String password;
    protected String specialization;  // Added for Doctor specialization

    // Static list to track all users
    private static List<User> users = new ArrayList<>();

    public User(int userId, String name, String email, String phone, String password) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.password = password;
        this.specialization = "";  // Default empty specialization
        users.add(this);  // Add user to the list when created
    }

    // Static method to get all users
    public static List<User> getUsers() {
        return users;
    }

    // Static method to clear all users (useful for testing)
    public static void clearUsers() {
        users.clear();
    }

    public void login(String email, String password) {
        System.out.println(name + " logged in.");
    }

    public void logout() {
        System.out.println(name + " logged out.");
    }

    public abstract String toString();

    // Getters
    public int getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getPassword() {
        return password;
    }

    public String getSpecialization() {
        return specialization;
    }

    // Setters
    public void setUserId(int userId) {
        this.userId = userId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public static void addUser(User user) { users.add(user); }

}