package User_Management;

import java.util.ArrayList;

public class Administrator extends User {
    ArrayList<Doctor> doctors;

    public Administrator(int userId, String name, String email, String phone, String password) {
        super(userId, name, email, phone, password);
        this.doctors = new ArrayList<>();
    }

    public void addDoctor(Doctor doctor) {
        doctors.add(doctor);
        System.out.println("Dr. " + doctor.getName()+" is now a part of this hospital.");
    }
    public void removeDoctor(Doctor doctor) {
        doctors.remove(doctor);
        System.out.println("Dr. " + doctor.getName()+" is no longer a part of this hospital");
    }
    public void viewDoctors() {
        System.out.println("List of Doctors:");
        if (doctors.isEmpty()) {
            System.out.println("No doctors registered yet.");
        } else {
            for (Doctor doctor : doctors) {
                System.out.println("- Dr. " + doctor.getName() + " (" + doctor.getSpecialization() + ")");
            }
        }
    }
    public void generateReport() {
        System.out.println("Hospital Report: ");
        System.out.println("Total Doctors: " + doctors.size());
        int totalPatients = 0;
        for (Doctor doctor : doctors) {
            totalPatients += doctor.getPatients().size();
        }
        System.out.println("Total Patients: " + totalPatients);
    }

    @Override
    public String toString() {
        return String.format("Administrator: %s\nEmail: %s\nPhone: %s", name, email, phone);
    }
}
