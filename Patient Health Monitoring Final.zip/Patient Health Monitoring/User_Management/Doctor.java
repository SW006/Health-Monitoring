package User_Management;

import java.util.ArrayList;
import java.util.List;

public class Doctor extends User {
    private String specialization;
    private ArrayList<Patient> patients;

    public Doctor(int userId, String name, String email, String phone, String password, String specialization) {
        super(userId, name, email, phone, password);
        this.specialization = specialization;
        this.patients = new ArrayList<>();
    }

    public String getSpecialization() {
        return specialization;
    }

    public List<Patient> getPatients() {
        return new ArrayList<>(patients); // Return a copy to prevent external modification
    }

    public void addPatient(Patient patient) {
        if (!patients.contains(patient)) {
            patients.add(patient);
            System.out.println(patient.getName() + " added to Dr. " + name + "'s list.");
        }
    }

    public void removePatient(Patient patient) {
        if (patients.remove(patient)) {
            System.out.println(patient.getName() + " removed from Dr. " + name + "'s list.");
        }
    }

    public void displayPatients() {
        System.out.println("Dr. " + name + "'s list of patients:");
        if (patients.isEmpty()) {
            System.out.println("No patients assigned yet.");
        } else {
            for (Patient p : patients) {
                System.out.println("- " + p.getName());
            }
        }
    }

    @Override
    public String toString() {
        return String.format("Doctor: %s\nSpecialization: %s\nEmail: %s\nPhone: %s",
                name, specialization, email, phone);
    }
}
