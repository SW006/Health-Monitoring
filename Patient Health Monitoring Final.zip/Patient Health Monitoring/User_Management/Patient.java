package User_Management;
import Doctor_Patient_Interaction.MedicalHistory;
import Doctor_Patient_Interaction.Feedback;
import Doctor_Patient_Interaction.Prescription;
import java.util.List;
import java.util.ArrayList;

public class Patient extends User {
    private String dob;
    private char gender;
    private MedicalHistory medicalRecord;
    private String emergencyContact;
    private Doctor primaryDoctor;
    private List<Feedback> feedbacks;
    private List<Prescription> prescriptions;

    //Constructor
    public Patient(int userId, String name, String email, String phone, String password, String dob, char gender, String emergencyContact, Doctor primaryDoctor) {
        super(userId, name, email, phone, password);
        this.dob = dob;
        this.gender = gender;
        this.medicalRecord = new MedicalHistory(this);
        this.emergencyContact = emergencyContact;
        this.primaryDoctor = primaryDoctor;
        this.feedbacks = new ArrayList<>();
        this.prescriptions = new ArrayList<>();
    }

    //Getters
    public char getGender() {
        return gender;
    }

    public String getEmergencyContact() {
        return emergencyContact;
    }

    public String getDob() {
        return dob;
    }

    // Alias method for getMedicalRecord to maintain compatibility
    public MedicalHistory getMedicalHistory() {
        return medicalRecord;
    }

    public MedicalHistory getMedicalRecord() {
        return medicalRecord;
    }

    public Doctor getPrimaryDoctor() {
        return primaryDoctor;
    }

    public List<Feedback> getFeedbacks() {
        return feedbacks;
    }

    public List<Prescription> getPrescriptions() {
        return prescriptions;
    }

    //Setters
    public void setEmergencyContact(String emergencyContact) {
        this.emergencyContact = emergencyContact;
    }

    public void setPrimaryDoctor(Doctor primaryDoctor) {
        this.primaryDoctor = primaryDoctor;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    //Methods
    public void bookAppointment(Doctor doctor, String date) {
        System.out.println(name + " booked an appointment with Dr. " + doctor.getName() + " on " + date);
    }

    public void viewMedicalHistory() {
        medicalRecord.displayMedicalHistory();
    }

    public void addFeedback(Feedback feedback) {
        feedbacks.add(feedback);
        medicalRecord.addFeedback(feedback);
    }

    public void addPrescription(Prescription prescription) {
        prescriptions.add(prescription);
        medicalRecord.addPrescription(prescription);
    }

    public int getAge() {
        try {
            String[] parts = dob.split("-");
            int birthYear = Integer.parseInt(parts[0]);
            java.util.Calendar now = java.util.Calendar.getInstance();
            int currentYear = now.get(java.util.Calendar.YEAR);
            return currentYear - birthYear;
        } catch (Exception e) {
            return 0;
        }
    }

    public String getGenderString() {
        return gender == 'M' ? "Male" : gender == 'F' ? "Female" : "Other";
    }

    public String getFormattedPhone() {
        String phoneStr = String.valueOf(phone);
        return phoneStr.length() == 10 ? 
            String.format("(%s) %s-%s", 
                phoneStr.substring(0, 3),
                phoneStr.substring(3, 6),
                phoneStr.substring(6)) : 
            phoneStr;
    }

    public String getFormattedDob() {
        try {
            String[] parts = dob.split("-");
            return String.format("%s/%s/%s", parts[1], parts[2], parts[0]);
        } catch (Exception e) {
            return dob;
        }
    }

    public void addMedicalNote(String note) {
        if (medicalRecord != null) {
            medicalRecord.addNotes(note);
        }
    }

    public boolean hasActivePrescriptions() {
        return !prescriptions.isEmpty();
    }

    public boolean hasFeedback() {
        return !feedbacks.isEmpty();
    }

    // New method to get patient's full details for display
    public String getFullDetails() {
        return String.format("""
            Patient Details:
            ID: %d
            Name: %s
            Email: %s
            Phone: %s
            Age: %d
            Gender: %s
            Date of Birth: %s
            Emergency Contact: %s
            Primary Doctor: Dr. %s
            Active Prescriptions: %s
            Has Feedback: %s
            """,
            userId,
            name,
            email,
            getFormattedPhone(),
            getAge(),
            getGenderString(),
            getFormattedDob(),
            emergencyContact,
            primaryDoctor != null ? primaryDoctor.getName() : "Not Assigned",
            hasActivePrescriptions() ? "Yes" : "No",
            hasFeedback() ? "Yes" : "No"
        );
    }

    @Override
    public String toString() {
        return String.format("""
            Patient Information:
            Name: %s
            Age: %d
            Gender: %s
            Phone: %s
            Emergency Contact: %s
            Primary Doctor: Dr. %s
            """, 
            name, 
            getAge(), 
            getGenderString(), 
            getFormattedPhone(), 
            emergencyContact,
            primaryDoctor != null ? primaryDoctor.getName() : "Not Assigned"
        );
    }
}