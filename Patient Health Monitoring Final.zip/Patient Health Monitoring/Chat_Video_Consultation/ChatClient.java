package Chat_Video_Consultation;

/**
 * Client-side chat interface for patients and doctors.
 */
public class ChatClient {
    private String username;
    private ChatServer server;

    public ChatClient(String username, ChatServer server) {
        if (username == null || username.isEmpty()) {
            throw new IllegalArgumentException("Username cannot be null or empty.");
        }
        if (server == null) {
            throw new IllegalArgumentException("Server reference cannot be null.");
        }
        this.username = username;
        this.server = server;
    }

    /**
     * Sends a message to the server.
     */
    public void sendMessage(String message) {
        if (message == null || message.trim().isEmpty()) {
            System.err.println("Cannot send an empty message.");
            return;
        }
        String formattedMessage = username + ": " + message;
        server.receiveMessage(formattedMessage);
    }

    /**
     * Displays the message history from the server.
     */
    public void viewChatHistory() {
        System.out.println("Chat history for " + username + ":");
        for (String msg : server.getMessageLog()) {
            System.out.println(msg);
        }
    }
}
