package Chat_Video_Consultation;

import java.util.ArrayList;

/**
 * Handles doctor-patient chat messages.
 */
public class ChatServer {
    private ArrayList<String> messageLog;

    public ChatServer() {
        messageLog = new ArrayList<>();
    }

    /**
     * Receives and stores a message from a client
     */
    public void receiveMessage(String message) {
        if (message == null || message.trim().isEmpty()) {
            System.err.println("Error: Cannot receive null or empty message.");
            return;
        }
        messageLog.add(message);
        System.out.println("Received: " + message);
    }

    /**
     * Returns the message history.
     * @return copy of chat messages
     */
    public ArrayList<String> getMessageLog() {
        return new ArrayList<>(messageLog); // Return a copy to protect internal list
    }
}
