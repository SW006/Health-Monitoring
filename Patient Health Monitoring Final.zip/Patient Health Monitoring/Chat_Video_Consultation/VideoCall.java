package Chat_Video_Consultation;

public class VideoCall {
    private String platform;
    private String meetingLink;

    public VideoCall(String platform, String meetingLink) {
        if (platform == null || platform.isEmpty() || meetingLink == null || meetingLink.isEmpty()) {
            throw new IllegalArgumentException("Platform and meeting link cannot be empty");
        }
        this.platform = platform;
        this.meetingLink = meetingLink;
    }

    public void startCall() {
        try {
            System.out.println("Starting " + platform + " video call...");
            System.out.println("Join at: " + meetingLink);
            // In a real implementation, this would launch the video call
        } catch (Exception e) {
            System.err.println("Failed to start video call: " + e.getMessage());
        }
    }

    public void endCall() {
        System.out.println("Ending " + platform + " video call");
    }
}