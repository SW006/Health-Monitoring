package Health_Data_Handling;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import MDBS.DB_Connector;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.ChartPanel;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.Millisecond;
import java.text.ParseException;
import java.text.SimpleDateFormat;

// Assuming these are in a Health_Data_Handling class
public class VitalSign {

    public VitalSign(int i, int i1, int i2, int i3) {
    }

    // Method to create the Vitals table (if it doesn't exist)
    public static void createTable() throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DB_Connector.getConnection();
            String sql = "CREATE TABLE IF NOT EXISTS Vitals ( "
                    + " id INTEGER auto_increment primary key, "
                    + " patient_id INTEGER NOT NULL, "
                    + " date TIMESTAMP NOT NULL, " // Changed to TIMESTAMP
                    + " heart_rate DOUBLE, "
                    + " temperature DOUBLE, "
                    + " systolic_bp DOUBLE, " // Added systolic BP
                    + " diastolic_bp DOUBLE, " // Added diastolic BP
                    + " oxygen_level DOUBLE, "
                    + " FOREIGN KEY (patient_id) REFERENCES patients(patient_id), "
                    + " UNIQUE (patient_id, date) " // Added unique constraint
                    + ")";
            pstmt = conn.prepareStatement(sql);
            pstmt.executeUpdate();
            System.out.println("Vitals table created (if needed).");
        } catch (SQLException e) {
            throw e; // Re-throw the exception to be handled by the caller
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace(); // Log the error, but don't throw it again
            }
        }
    }

    // Method to load data from a CSV file into the Vitals table
    public static void loadFromCSV(File csvFile, int patientId) throws SQLException, IOException, ParseException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        BufferedReader br = null;
        try {
            conn = DB_Connector.getConnection();
            String sql = "INSERT INTO Vitals (patient_id, date, heart_rate, temperature, systolic_bp, diastolic_bp, oxygen_level) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            br = new BufferedReader(new FileReader(csvFile));
            String line;
            // Skip the header row
            br.readLine();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); // Define the expected date format

            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length == 7) { // Ensure correct number of values
                    try {
                        // Parse the date string into a java.sql.Timestamp
                        java.util.Date parsedDate = dateFormat.parse(values[2]);
                        Timestamp timestamp = new Timestamp(parsedDate.getTime());
                        String[] bpValues = values[5].split("/");  // Split BP
                        double systolic = Double.parseDouble(bpValues[0]);
                        double diastolic = Double.parseDouble(bpValues[1]);

                        pstmt.setInt(1, patientId);
                        pstmt.setTimestamp(2, timestamp); // Use setTimestamp
                        pstmt.setDouble(3, Double.parseDouble(values[3]));
                        pstmt.setDouble(4, Double.parseDouble(values[4]));
                        pstmt.setDouble(5, systolic);  // Set systolic
                        pstmt.setDouble(6, diastolic);  // Set diastolic
                        pstmt.setDouble(7, Double.parseDouble(values[6]));
                        pstmt.executeUpdate();
                    } catch (NumberFormatException | ParseException e) {
                        System.err.println("Error parsing line: " + line + " - " + e.getMessage());
                        // Consider logging the error or skipping the invalid line
                    }
                } else {
                    System.err.println("Skipping invalid line: " + line);
                }
            }
            System.out.println("Vitals data imported from CSV for patient: " + patientId);
        } catch (SQLException | IOException e) {
            throw e; // Re-throw exceptions
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
                if (br != null) {
                    br.close();
                }
            } catch (SQLException | IOException e) {
                e.printStackTrace();
            }
        }
    }

    // Method to get vital signs data for a specific patient
    public static List<VitalSign> getVitalsByPatientId(int patientId) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<VitalSign> vitalsList = new ArrayList<>();
        try {
            conn = DB_Connector.getConnection();
            String sql = "SELECT id, date, heart_rate, temperature, systolic_bp, diastolic_bp, oxygen_level "
                    + "FROM Vitals WHERE patient_id = ? ORDER BY date"; // Order by date
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, patientId);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                VitalSign vital = new VitalSign();
                vital.setId(rs.getInt("id"));
                vital.setDate(rs.getTimestamp("date")); // Use getTimestamp
                vital.setHeartRate(rs.getDouble("heart_rate"));
                vital.setTemperature(rs.getDouble("temperature"));
                vital.setSystolicBp(rs.getDouble("systolic_bp")); // Get systolic
                vital.setDiastolicBp(rs.getDouble("diastolic_bp")); // Get diastolic
                vital.setOxygenLevel(rs.getDouble("oxygen_level"));
                vitalsList.add(vital);
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return vitalsList;
    }

    // Method to generate a line chart of vital signs for a specific patient
    public static JFreeChart getLineChart(int patientId) throws SQLException {
        TimeSeriesCollection dataset = new TimeSeriesCollection();
        // Create TimeSeries for each vital sign
        TimeSeries heartRateSeries = new TimeSeries("Heart Rate");
        TimeSeries temperatureSeries = new TimeSeries("Temperature");
        TimeSeries systolicBpSeries = new TimeSeries("Systolic BP");  // Systolic
        TimeSeries diastolicBpSeries = new TimeSeries("Diastolic BP");  // Diastolic
        TimeSeries oxygenLevelSeries = new TimeSeries("Oxygen Level");

        // Get vitals data for the specified patient
        List<VitalSign> vitalsList = VitalSign.getVitalsByPatientId(patientId);

        // Populate the TimeSeries with data from the database
        for (VitalSign vital : vitalsList) {
            Millisecond time = new Millisecond(vital.getDate()); // Use the date from the vital
            if (!Double.isNaN(vital.getHeartRate())) {
                heartRateSeries.add(time, vital.getHeartRate());
            }
            if (!Double.isNaN(vital.getTemperature())) {
                temperatureSeries.add(time, vital.getTemperature());
            }
            if (!Double.isNaN(vital.getSystolicBp())) {
                systolicBpSeries.add(time, vital.getSystolicBp());
            }
            if (!Double.isNaN(vital.getDiastolicBp())) {
                diastolicBpSeries.add(time, vital.getDiastolicBp());
            }
            if (!Double.isNaN(vital.getOxygenLevel())) {
                oxygenLevelSeries.add(time, vital.getOxygenLevel());
            }
        }
        // Add the TimeSeries to the dataset
        dataset.addSeries(heartRateSeries);
        dataset.addSeries(temperatureSeries);
        dataset.addSeries(systolicBpSeries);  // Add the systolic series
        dataset.addSeries(diastolicBpSeries);  // Add the diastolic series
        dataset.addSeries(oxygenLevelSeries);

        // Create the chart
        JFreeChart chart = ChartFactory.createTimeSeriesChart(
                "Patient Vital Signs", // Chart title
                "Date/Time",             // X-Axis label
                "Value",                  // Y-Axis label
                dataset,                 // Dataset
                true,                    // Include legend
                true,                    // Include tooltips
                false                    // Include URL generation
        );
        return chart;
    }

    private int id;
    private Timestamp date;
    private double heartRate;
    private double temperature;
    private double systolicBp;
    private double diastolicBp;
    private double oxygenLevel;

    public VitalSign() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Timestamp getDate() {
        return date;
    }

    public void setDate(Timestamp date) {
        this.date = date;
    }

    public double getHeartRate() {
        return heartRate;
    }

    public void setHeartRate(double heartRate) {
        this.heartRate = heartRate;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    public double getSystolicBp() {
        return systolicBp;
    }

    public void setSystolicBp(double systolicBp) {
        this.systolicBp = systolicBp;
    }

    public double getDiastolicBp() {
        return diastolicBp;
    }

    public void setDiastolicBp(double diastolicBp) {
        this.diastolicBp = diastolicBp;
    }

    public double getOxygenLevel() {
        return oxygenLevel;
    }

    public void setOxygenLevel(double oxygenLevel) {
        this.oxygenLevel = oxygenLevel;
    }
}