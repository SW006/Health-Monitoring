package Health_Data_Handling;

import java.util.ArrayList;
import java.util.HashMap;
import User_Management.Patient;

public class VitalsDatabase {
    private HashMap<Patient, ArrayList<VitalSign>> vitalsRecords;

    public VitalsDatabase() {
        this.vitalsRecords = new HashMap<>();
    }

    public void addVitals(Patient patient, VitalSign vital) {
        vitalsRecords.putIfAbsent(patient, new ArrayList<>());
        vitalsRecords.get(patient).add(vital);
        System.out.println("Vitals recorded for " + patient.getName());
    }

    public void displayPatientVitals(Patient patient) {
        if (vitalsRecords.containsKey(patient)) {
            System.out.println("----Vitals---- \nVitals for" + patient.getName() + ":");
            for (VitalSign v : vitalsRecords.get(patient)) {
                System.out.println(v);;
            }
        } else {
            System.out.println("No vitals recorded for " + patient.getName());
        }
    }
}

