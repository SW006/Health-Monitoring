package Emergency_Alert_System;

import User_Management.Patient;
import Health_Data_Handling.VitalSign;

/**
 * Allows patients to manually trigger emergency alerts
 */
public class PanicButton {
    private Patient patient;
    private NotificationService notificationService;

    public PanicButton(Patient patient, NotificationService notificationService) {
        this.patient = patient;
        this.notificationService = notificationService;
    }

    /**
     * Triggers a manual emergency alert
     */
    public void press() {
        // Create a dummy vital sign to indicate manual trigger
        VitalSign dummyVital = new VitalSign(0, 0, 0, 0) {
            @Override
            public String toString() {
                return "MANUAL PANIC BUTTON ACTIVATED";
            }
        };

        EmergencyAlert alert = new EmergencyAlert(
                patient,
                dummyVital
        ) {
            @Override
            public String getAlertType() {
                return "Manual Panic Button Activation";
            }
        };

        notificationService.sendEmergencyAlert(alert);
        System.out.println("Panic button pressed by " + patient.getName());
    }

    /**
     * Test the panic button functionality
     */
    public void testButton() {
        System.out.println("Testing panic button for " + patient.getName());
        this.press();
    }
}