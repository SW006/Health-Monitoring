package Emergency_Alert_System;

import GUI_INterface.DoctorDashboard; // Import the DoctorDashboard class
import Notification_and_Reminder.Notifiable;

import java.util.InputMismatchException;

/**
 * Handles sending notifications through different channels
 */
public class NotificationService implements Notifiable{
    private Notifiable emailNotifier;
    private Notifiable smsNotifier;
    private DoctorDashboard doctorDashboard; // Add a reference to the DoctorDashboard

    public NotificationService(Notifiable emailNotifier, Notifiable smsNotifier) {
        this.emailNotifier = emailNotifier;
        this.smsNotifier = smsNotifier;
    }

    // Method to set the DoctorDashboard instance
    public void setDoctorDashboard(DoctorDashboard dashboard) {
        this.doctorDashboard = dashboard;
    }

    public void sendAlert(String recipient, String message) throws InputMismatchException {
        // Determine if recipient is email or phone number
        if (recipient.contains("@")) {
            emailNotifier.sendNotification(recipient, message);
        } else {
            smsNotifier.sendNotification(recipient, message);
        }
    }

    public void sendEmergencyAlert(EmergencyAlert alert) {
        String message = String.format(
                "EMERGENCY ALERT for patient %s (%s)\n" + // Include patient ID
                        "Type: %s\n" +
                        "Time: %tc\n" +
                        "Vitals:\n%s",
                alert.getPatient().getName(),
                alert.getPatient().getUserId(),
                alert.getAlertType(),
                alert.getTimestamp(),
                alert.getVitalSign().toString()
        );

        // Send to both doctor and emergency contact (email/SMS)
        if (alert.getPatient().getPrimaryDoctor() != null && alert.getPatient().getPrimaryDoctor().getEmail() != null) {
            sendAlert(alert.getPatient().getPrimaryDoctor().getEmail(), message);
        }
        if (alert.getPatient().getEmergencyContact() != null) {
            sendAlert(alert.getPatient().getEmergencyContact(), message);
        }

        // Also, notify the doctor's dashboard if it's active and for the correct doctor
        if (doctorDashboard != null && alert.getPatient().getPrimaryDoctor() != null &&
                alert.getPatient().getPrimaryDoctor().getUserId() == doctorDashboard.getDoctor().getUserId()) {
            doctorDashboard.receiveAlert(alert);
        }
    }

    @Override
    public void sendNotification(String recipient, String message) {
        // This method is part of the Notifiable interface but its implementation
        // is handled by emailNotifier and smsNotifier in sendAlert.
    }
}