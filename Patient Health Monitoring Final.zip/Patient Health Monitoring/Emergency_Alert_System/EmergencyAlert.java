package Emergency_Alert_System;

import User_Management.Patient;
import java.util.Date;
import Health_Data_Handling.VitalSign;

public class EmergencyAlert {
    private Patient patient;
    private String alertType;
    private Date timestamp;
    private VitalSign vitalSign;
    private static final double CRITICAL_HEART_RATE = 120.0;
    private static final double CRITICAL_LOW_OXYGEN = 90.0;
    private static final double CRITICAL_HIGH_BP = 140.0;
    private static final double CRITICAL_LOW_BP = 90.0;
    private static final double CRITICAL_HIGH_TEMP = 38.0;
    private static final double CRITICAL_LOW_TEMP = 35.0;

    public EmergencyAlert(Patient patient, VitalSign vitalSign) {
        this.patient = patient;
        this.vitalSign = vitalSign;
        this.timestamp = new Date();
        this.alertType = checkCriticalVitals();
    }

    private String checkCriticalVitals() {
        StringBuilder alert = new StringBuilder();

        if (vitalSign.getHeartRate() > CRITICAL_HEART_RATE) {
            alert.append("High Heart Rate (").append(vitalSign.getHeartRate()).append(" bpm), ");
        }

        if (vitalSign.getOxygenLevel() < CRITICAL_LOW_OXYGEN) {
            alert.append("Low Oxygen Level (").append(vitalSign.getOxygenLevel()).append("%), ");
        }

        if (vitalSign.getSystolicBp() > CRITICAL_HIGH_BP) {
            alert.append("High Blood Pressure (").append(vitalSign.getSystolicBp()).append(" mmHg), ");
        } else if (vitalSign.getDiastolicBp() < CRITICAL_LOW_BP) {
            alert.append("Low Blood Pressure (").append(vitalSign.getDiastolicBp()).append(" mmHg), ");
        }

        if (vitalSign.getTemperature() > CRITICAL_HIGH_TEMP) {
            alert.append("High Temperature (").append(vitalSign.getTemperature()).append("°C), ");
        } else if (vitalSign.getTemperature() < CRITICAL_LOW_TEMP) {
            alert.append("Low Temperature (").append(vitalSign.getTemperature()).append("°C), ");
        }

        if (alert.length() == 0) {
            return "Normal";
        } else {
            // Remove the trailing comma and space
            return alert.substring(0, alert.length() - 2);
        }
    }

    public boolean isCritical() {
        return !alertType.equals("Normal");
    }
    public void triggerAlert(NotificationService notificationService) {
        if (isCritical()) {
            String message = String.format(
                    "EMERGENCY ALERT for patient %s (%s)\n" +
                            "Critical vitals detected: %s\n" +
                            "Recorded at: %s\n" +
                            "Current vitals:\n%s",
                    patient.getName(),
                    patient.getUserId(),
                    alertType,
                    timestamp,
                    vitalSign.toString()
            );

            // Get email/phone from patient's doctor and emergency contact
            notificationService.sendAlert(patient.getPrimaryDoctor().getEmail(), message);
        }
    }

            // Getters
            public Patient getPatient() {
                return patient;
            }

            public String getAlertType() {
                return alertType;
            }

            public Date getTimestamp () {
                return new Date(timestamp.getTime());
            }

            public VitalSign getVitalSign() {
                return vitalSign;
            }
        }
