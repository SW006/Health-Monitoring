// DB_Connector.java
package MDBS;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;

public class DB_Connector {
    private static final String URL = "jdbc:mysql://localhost:3306/hospital_db?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String USERNAME = System.getenv("DB_USERNAME") != null ? System.getenv("DB_USERNAME") : "root";
    private static final String PASSWORD = System.getenv("DB_PASSWORD") != null ? System.getenv("DB_PASSWORD") : "SomethingEasy24";
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";

    private static Connection connection = null;
    private static boolean driverLoaded = false;

    static {
        try {
            // Load the MySQL JDBC driver
            Class.forName(DRIVER);
            driverLoaded = true;
            System.out.println("MySQL JDBC Driver loaded successfully!");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found! Please check your dependencies.");
            e.printStackTrace();
        }
    }

    public static Connection getConnection() {
        if (!driverLoaded) {
            System.err.println("Cannot establish connection: MySQL JDBC Driver not loaded!");
            return null;
        }

        if (connection == null || !isConnectionValid()) {
            try {
                // Try to establish connection
                connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                
                // Verify connection is valid
                if (connection.isValid(5)) {
                    System.out.println("Connected to database successfully!");
                    
                    // Verify database exists
                    try (Statement stmt = connection.createStatement();
                         ResultSet rs = stmt.executeQuery("SELECT DATABASE()")) {
                        if (rs.next()) {
                            String dbName = rs.getString(1);
                            if (dbName == null || !dbName.equals("hospital_db")) {
                                System.err.println("Warning: Not connected to hospital_db database!");
                            }
                        }
                    }
                } else {
                    System.err.println("Database connection is not valid!");
                    connection = null;
                }
            } catch (SQLException e) {
                System.err.println("Connection failed! Error: " + e.getMessage());
                System.err.println("Please make sure:");
                System.err.println("1. MySQL server is running");
                System.err.println("2. Database 'hospital_db' exists");
                System.err.println("3. Database credentials are correct");
                e.printStackTrace();
                connection = null;
            }
        }
        return connection;
    }

    private static boolean isConnectionValid() {
        try {
            return connection != null && connection.isValid(5);
        } catch (SQLException e) {
            return false;
        }
    }

    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;
                System.out.println("Connection closed successfully!");
            } catch (SQLException e) {
                System.err.println("Error closing connection! Error: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    // Helper method to execute queries with prepared statements
    public static ResultSet executeQuery(String query, Object... params) {
        Connection conn = getConnection();
        if (conn == null) {
            System.err.println("Cannot execute query: No database connection!");
            return null;
        }

        try {
            PreparedStatement pstmt = conn.prepareStatement(query);
            for (int i = 0; i < params.length; i++) {
                pstmt.setObject(i + 1, params[i]);
            }
            return pstmt.executeQuery();
        } catch (SQLException e) {
            System.err.println("Error executing query: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    // Helper method to execute updates (INSERT, UPDATE, DELETE) with prepared statements
    public static int executeUpdate(String query, Object... params) {
        Connection conn = getConnection();
        if (conn == null) {
            System.err.println("Cannot execute update: No database connection!");
            return -1;
        }

        try {
            PreparedStatement pstmt = conn.prepareStatement(query);
            for (int i = 0; i < params.length; i++) {
                pstmt.setObject(i + 1, params[i]);
            }
            return pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error executing update: " + e.getMessage());
            e.printStackTrace();
            return -1;
        }
    }
}
