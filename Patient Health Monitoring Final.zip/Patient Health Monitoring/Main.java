import GUI_INterface.LoginFrame;
import Notification_and_Reminder.EmailNotification;
import User_Management.Administrator;
import User_Management.Doctor;
import User_Management.Patient;
import User_Management.User;
import Health_Data_Handling.VitalSign;

import javax.swing.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        try {
            // Initialize SQLite database
            try {
                VitalSign.createTable();
            } catch (SQLException e) {
                System.err.println("Warning: Could not initialize vitals database: " + e.getMessage());
                // Continue execution as this is not critical
            }

            // Create sample users
            Administrator admin = new Administrator(1, "Admin", "admin@hospital.com", "1234567890", "admin123");
            Doctor doctor = new Doctor(2, "Dr. Smith", "doctor@hospital.com", "987654321", "doc123", "Cardiology");
            Patient patient = new Patient(3, "John Doe", "patient@example.com", "555123456", "patient123",
                    "1990-01-01", 'M', "555-9876", doctor);

            // Add patient to doctor's list
            doctor.addPatient(patient);

            // Create a test patient
            Patient testPatient = new Patient(
                    1, "Alice Johnson", "alice.johnson@example.com", "123456789", "password123",
                    "1995-04-22", 'F', "999888777", doctor
            );

            // Create list of users
            List<User> users = new ArrayList<>();
            users.add(admin);
            users.add(doctor);
            users.add(patient);
            users.add(testPatient);

            // Initialize email notification system
            try {
                EmailNotification notification = new EmailNotification("hospital@gmail.com", "password");
                String message = "Dear " + testPatient.getName() + ", this is a test email from our hospital system.";
                notification.sendNotification(testPatient, message);
            } catch (Exception e) {
                System.err.println("Warning: Email notification system not available: " + e.getMessage());
                // Continue execution as this is not critical
            }

            // Start the login frame
            SwingUtilities.invokeLater(() -> {
                try {
                    LoginFrame loginFrame = new LoginFrame(users); // Pass the users list here
                    loginFrame.setVisible(true);
                } catch (Exception e) {
                    System.err.println("Error starting login frame: " + e.getMessage());
                    e.printStackTrace();
                    System.exit(1);
                }
            });

        } catch (Exception e) {
            System.err.println("Critical error initializing the application: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}
